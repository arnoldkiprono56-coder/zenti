import { Router, Request, Response } from "express";
import { db } from "@workspace/db";
import { transactionsTable, usersTable, activityLogsTable, fraudFlagsTable, referralsTable, platformSettingsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../middlewares/auth";
import { initiateSTKPush } from "../lib/payhero";

const router = Router();

router.get("/", requireAuth, async (req: AuthRequest, res: Response) => {
  const txns = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.userId, req.userId!))
    .orderBy(sql`${transactionsTable.createdAt} desc`);
  res.json(txns.map(serializeTxn));
});

/** Lightweight status check used by frontend polling */
router.get("/:id/status", requireAuth, async (req: AuthRequest, res: Response) => {
  const id = parseInt(String(req.params["id"]));
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [txn] = await db
    .select({ id: transactionsTable.id, status: transactionsTable.status, amount: transactionsTable.amount })
    .from(transactionsTable)
    .where(eq(transactionsTable.id, id))
    .limit(1);
  if (!txn || txn === undefined) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ id: txn.id, status: txn.status, amount: parseFloat(txn.amount) });
});

router.post("/deposit", requireAuth, async (req: AuthRequest, res: Response) => {
  const { amount, phone } = req.body;
  if (!amount || !phone) {
    res.status(400).json({ error: "Amount and phone are required" });
    return;
  }
  if (amount < 10) {
    res.status(400).json({ error: "Minimum deposit is KES 10" });
    return;
  }
  if (!/^(07|01|\+2547|\+2541)\d{8}$/.test(phone.replace(/\s/g, ""))) {
    res.status(400).json({ error: "Invalid M-Pesa phone number" });
    return;
  }

  // Fraud check: multiple large deposits in short window
  const recentLarge = await db
    .select()
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'deposit' AND ${transactionsTable.createdAt} > now() - interval '1 hour' AND ${transactionsTable.amount}::numeric > 50000`
    );

  // Create pending transaction
  const [txn] = await db.insert(transactionsTable).values({
    userId: req.userId!,
    type: "deposit",
    amount: String(amount),
    status: "pending",
    method: "mpesa",
    phoneOrAccount: phone,
    reference: `PENDING-${Date.now()}`,
  }).returning();

  // Flag suspicious activity
  if (recentLarge.length > 0 || amount > 100000) {
    await db.insert(fraudFlagsTable).values({
      transactionId: txn.id,
      reason: amount > 100000
        ? "Large deposit exceeds KES 100,000"
        : "Multiple large deposits in 1-hour window",
      severity: amount > 500000 ? "high" : "medium",
    });
    await db.update(transactionsTable).set({ isFlagged: true }).where(eq(transactionsTable.id, txn.id));
  }

  // Derive callback URL (use APP_URL env or fallback to request host)
  const appUrl =
    process.env["APP_URL"] ??
    `${req.protocol}://${req.headers["x-forwarded-host"] ?? req.get("host")}`;
  const callbackUrl = `${appUrl}/api/transactions/callback/payhero`;

  // Fetch user name for PayHero
  const [user] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);

  // Initiate PayHero STK push
  try {
    const result = await initiateSTKPush({
      amount,
      phone,
      externalReference: `TXN-${txn.id}`,
      callbackUrl,
      customerName: user?.fullName ?? "Customer",
    });

    // Store the PayHero CheckoutRequestID as the transaction reference
    await db.update(transactionsTable)
      .set({ reference: result.checkoutRequestId })
      .where(eq(transactionsTable.id, txn.id));

    res.json({
      message: "STK push sent. Check your phone for the M-Pesa prompt.",
      transactionId: txn.id,
      checkoutRequestId: result.checkoutRequestId,
    });
  } catch (err) {
    // STK push failed — mark transaction as failed
    await db.update(transactionsTable)
      .set({ status: "failed" })
      .where(eq(transactionsTable.id, txn.id));

    const message = err instanceof Error ? err.message : "Failed to initiate M-Pesa payment";
    res.status(502).json({ error: message });
  }
});

/**
 * PayHero callback — unauthenticated, called by PayHero servers.
 * Credits the user's balance on SUCCESS; marks FAILED on failure.
 */
router.post("/callback/payhero", async (req: Request, res: Response) => {
  const body = req.body as Record<string, unknown>;

  const externalReference = String(body["external_reference"] ?? "");
  const status = String(body["status"] ?? "").toUpperCase();
  const rawAmount = parseFloat(String(body["amount"] ?? "0"));

  // Always respond 200 quickly so PayHero doesn't retry
  res.json({ received: true });

  if (!externalReference.startsWith("TXN-")) return;
  const txnId = parseInt(externalReference.replace("TXN-", ""));
  if (isNaN(txnId)) return;

  const [txn] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, txnId))
    .limit(1);

  if (!txn || txn.status !== "pending") return; // already processed

  if (status === "SUCCESS") {
    const confirmedAmount = rawAmount > 0 ? rawAmount : parseFloat(txn.amount);

    // Mark transaction completed
    await db.update(transactionsTable)
      .set({ status: "completed", amount: String(confirmedAmount), updatedAt: new Date() })
      .where(eq(transactionsTable.id, txnId));

    // Credit user balance
    await db.update(usersTable)
      .set({
        balance: sql`${usersTable.balance} + ${confirmedAmount}`,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, txn.userId));

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, txn.userId)).limit(1);

    await db.insert(activityLogsTable).values({
      userId: txn.userId,
      userEmail: user?.email ?? "unknown",
      action: "deposit_completed",
      details: `PayHero M-Pesa deposit of KES ${confirmedAmount} confirmed (ref: ${externalReference})`,
      ipAddress: "payhero-callback",
    });

    // Fire-and-forget WhatsApp deposit receipt
    if (user) {
      (async () => {
        try {
          const { sendMessage } = await import("../lib/whatsapp");
          const amountFmt = confirmedAmount.toLocaleString("en-KE", { minimumFractionDigits: 2 });
          const newBal = parseFloat(user.balance ?? "0") + confirmedAmount;
          const balFmt = newBal.toLocaleString("en-KE", { minimumFractionDigits: 2 });
          const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
          await sendMessage(user.phone,
            `💰 *Deposit Confirmed — Zenti*\n\nHi ${user.fullName},\n\nYour M-Pesa deposit has been received and credited to your wallet.\n\n` +
            `✅ *Amount Received:* KES ${amountFmt}\n🏦 *New Balance:* KES ${balFmt}\n📋 *Reference:* ${externalReference}\n🕐 *Time:* ${time}\n\n` +
            `Your funds are ready to invest. Log in to Zenti to get started! 🚀`
          );
        } catch { /* silent */ }
      })();

      // Fire-and-forget deposit confirmed email
      (async () => {
        try {
          const { sendDepositConfirmedEmail } = await import("../lib/email");
          const newBal = parseFloat(user.balance ?? "0") + confirmedAmount;
          await sendDepositConfirmedEmail(
            { email: user.email, name: user.fullName },
            { amount: confirmedAmount, newBalance: newBal, reference: externalReference, method: "M-Pesa" },
          );
        } catch { /* silent */ }
      })();
    }

    // Tier 1 referral bonus: 10% to referrer on first deposit
    const [referral] = await db
      .select()
      .from(referralsTable)
      .where(eq(referralsTable.refereeId, txn.userId))
      .limit(1);

    if (referral && !referral.depositBonusPaid) {
      const bonus = confirmedAmount * 0.10;
      const [referrer] = await db.select().from(usersTable).where(eq(usersTable.id, referral.referrerId)).limit(1);
      if (referrer) {
        await db.update(usersTable)
          .set({ balance: sql`${usersTable.balance} + ${bonus}` })
          .where(eq(usersTable.id, referrer.id));
        await db.update(referralsTable)
          .set({ depositBonusPaid: true })
          .where(eq(referralsTable.refereeId, txn.userId));
        await db.insert(activityLogsTable).values({
          userId: referrer.id,
          userEmail: referrer.email,
          action: "referral_deposit_bonus",
          details: `Referral bonus KES ${bonus.toFixed(2)} (10% of KES ${confirmedAmount} deposit by user #${txn.userId})`,
          ipAddress: "payhero-callback",
        });
      }
    }
  } else {
    // FAILED / CANCELLED
    await db.update(transactionsTable)
      .set({ status: "failed", updatedAt: new Date() })
      .where(eq(transactionsTable.id, txnId));
  }
});

router.post("/withdraw", requireAuth, async (req: AuthRequest, res: Response) => {
  const { amount, method, phoneOrAccount } = req.body;
  if (!amount || !method || !phoneOrAccount) {
    res.status(400).json({ error: "Amount, method, and phone/account are required" });
    return;
  }

  const grossAmount = parseFloat(String(amount));
  if (isNaN(grossAmount) || grossAmount <= 0) {
    res.status(400).json({ error: "Invalid amount" });
    return;
  }
  if (grossAmount < 200) {
    res.status(400).json({ error: "Minimum withdrawal is KES 200" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const balance = parseFloat(user.balance ?? "0");

  if (grossAmount > balance) {
    res.status(400).json({ error: "Insufficient balance" });
    return;
  }

  // Load platform limits
  const [settings] = await db.select().from(platformSettingsTable).limit(1);
  const feePercent = parseFloat(settings?.withdrawalFeePercent ?? "10");
  const dailyLimitKES = parseFloat(settings?.dailyWithdrawalLimitKES ?? "50000");
  const cooldownHours = settings?.withdrawalCooldownHours ?? 24;
  const holdingHours = settings?.minDepositHoldingHours ?? 24;

  // ── Cooldown check: one withdrawal per N hours ──────────────────────────────
  if (cooldownHours > 0) {
    const cooldownCutoff = new Date(Date.now() - cooldownHours * 3_600_000);
    const [last] = await db
      .select({ id: transactionsTable.id, createdAt: transactionsTable.createdAt })
      .from(transactionsTable)
      .where(
        sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'withdrawal' AND ${transactionsTable.status} != 'rejected' AND ${transactionsTable.createdAt} > ${cooldownCutoff}`
      )
      .limit(1);
    if (last) {
      const nextAt = new Date(last.createdAt.getTime() + cooldownHours * 3_600_000);
      const nextFmt = nextAt.toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
      res.status(400).json({ error: `You can only withdraw once every ${cooldownHours} hours. Next withdrawal available at: ${nextFmt}` });
      return;
    }
  }

  // ── Daily withdrawal limit ──────────────────────────────────────────────────
  if (dailyLimitKES > 0) {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const [todaySumRow] = await db
      .select({ sum: sql<string>`coalesce(sum(amount::numeric), 0)` })
      .from(transactionsTable)
      .where(
        sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'withdrawal' AND ${transactionsTable.status} != 'rejected' AND ${transactionsTable.createdAt} >= ${startOfDay}`
      );
    const todaySum = parseFloat(todaySumRow?.sum ?? "0");
    if (todaySum + grossAmount > dailyLimitKES) {
      const remaining = Math.max(0, dailyLimitKES - todaySum);
      res.status(400).json({
        error: `Daily withdrawal limit of KES ${dailyLimitKES.toLocaleString()} reached. You have withdrawn KES ${todaySum.toLocaleString()} today. Remaining: KES ${remaining.toLocaleString()}`,
      });
      return;
    }
  }

  // ── Deposit holding period: must wait N hours after any completed deposit ───
  if (holdingHours > 0) {
    const holdingCutoff = new Date(Date.now() - holdingHours * 3_600_000);
    const [recentDeposit] = await db
      .select({ id: transactionsTable.id, createdAt: transactionsTable.createdAt })
      .from(transactionsTable)
      .where(
        sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'deposit' AND ${transactionsTable.status} = 'completed' AND ${transactionsTable.createdAt} > ${holdingCutoff}`
      )
      .limit(1);
    if (recentDeposit) {
      const releaseAt = new Date(recentDeposit.createdAt.getTime() + holdingHours * 3_600_000);
      const releaseFmt = releaseAt.toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
      res.status(400).json({
        error: `Deposits must be held for ${holdingHours} hours before withdrawal. Your funds will be available at: ${releaseFmt}`,
      });
      return;
    }
  }

  // ── Calculate fee ───────────────────────────────────────────────────────────
  const feeAmount = parseFloat((grossAmount * feePercent / 100).toFixed(2));
  const netAmount = parseFloat((grossAmount - feeAmount).toFixed(2));

  // ── Fraud check: rapid withdrawals ─────────────────────────────────────────
  const recentWithdrawals = await db
    .select({ id: transactionsTable.id })
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'withdrawal' AND ${transactionsTable.createdAt} > now() - interval '10 minutes'`
    );

  const [txn] = await db.insert(transactionsTable).values({
    userId: req.userId!,
    type: "withdrawal",
    amount: String(grossAmount),
    fee: String(feeAmount),
    status: "pending",
    method: method as "mpesa" | "airtel_money" | "bank",
    phoneOrAccount,
    notes: `Fee: ${feePercent}% (KES ${feeAmount.toFixed(2)}). Net payout: KES ${netAmount.toFixed(2)}`,
  }).returning();

  if (recentWithdrawals.length >= 3) {
    await db.insert(fraudFlagsTable).values({
      transactionId: txn.id,
      reason: "Multiple withdrawal attempts within 10 minutes",
      severity: "high",
    });
    await db.update(transactionsTable).set({ isFlagged: true }).where(eq(transactionsTable.id, txn.id));
  }

  // Hold full gross amount from balance (including fee)
  await db.update(usersTable)
    .set({ balance: String(balance - grossAmount) })
    .where(eq(usersTable.id, req.userId!));

  await db.insert(activityLogsTable).values({
    userId: req.userId!,
    userEmail: user.email,
    action: "withdrawal_requested",
    details: `Withdrawal KES ${grossAmount} (fee: KES ${feeAmount}, net: KES ${netAmount}) via ${method} to ${phoneOrAccount}`,
    ipAddress: req.ip || "unknown",
  });

  // Fire-and-forget notification
  (async () => {
    try {
      const { sendMessage } = await import("../lib/whatsapp");
      const grossFmt = grossAmount.toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const feeFmt = feeAmount.toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const netFmt = netAmount.toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const methodFmt = String(method).replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
      const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
      await sendMessage(user.phone,
        `📤 *Withdrawal Request — Zenti*\n\nHi ${user.fullName},\n\nYour withdrawal request is under review.\n\n` +
        `💰 *Amount:* KES ${grossFmt}\n` +
        `💸 *Processing Fee (${feePercent}%):* KES ${feeFmt}\n` +
        `✅ *You will receive:* KES ${netFmt}\n` +
        `📲 *Method:* ${methodFmt}\n` +
        `🏦 *Account:* ${phoneOrAccount}\n` +
        `🕐 *Submitted:* ${time}\n\n` +
        `We will notify you once it is processed. Thank you! 🙏`
      );
    } catch { /* silent */ }
  })();

  // Fire-and-forget withdrawal requested email
  (async () => {
    try {
      const { sendWithdrawalRequestedEmail } = await import("../lib/email");
      await sendWithdrawalRequestedEmail(
        { email: user.email, name: user.fullName },
        { amount: grossAmount, fee: feeAmount, netAmount, method, account: phoneOrAccount, feePercent },
      );
    } catch { /* silent */ }
  })();

  res.status(201).json(serializeTxn(txn));
});

export function serializeTxn(txn: typeof transactionsTable.$inferSelect) {
  return {
    id: txn.id,
    userId: txn.userId,
    type: txn.type,
    amount: parseFloat(txn.amount),
    fee: parseFloat(txn.fee ?? "0"),
    status: txn.status,
    method: txn.method,
    phoneOrAccount: txn.phoneOrAccount,
    reference: txn.reference,
    isFlagged: txn.isFlagged,
    notes: txn.notes,
    createdAt: txn.createdAt,
  };
}

export default router;
