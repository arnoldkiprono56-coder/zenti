import { Layout } from "@/components/layout";
import { useGetSettings } from "@workspace/api-client-react";

export default function Privacy() {
  const { data: settings } = useGetSettings();
  const company = settings?.companyName ?? "Zenti";

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <h1 className="text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-muted-foreground text-sm mb-8">Last updated: June 2026</p>

        <div className="space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">1. Information We Collect</h2>
            <p className="text-muted-foreground leading-relaxed">
              We collect information you provide during registration (full name, email, phone number, national ID), transaction records, device and usage data, and communications you send to us. We do not collect payment card information — all payments are processed via M-Pesa.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. Mandatory Verification & Fraud Prevention</h2>
            <p className="text-muted-foreground leading-relaxed">
              To protect users and maintain platform integrity, {company} requires all accounts to be verified via a one-time password (OTP) delivered through WhatsApp or email. Your phone number and email address are used exclusively for this verification and for platform notifications. Verification data is stored securely and is never sold or shared with third parties except as required by Kenyan law. Unverified accounts are automatically blocked from all platform features until verification is complete.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. How We Use Your Information</h2>
            <p className="text-muted-foreground leading-relaxed">
              Your data is used to: operate and maintain your account, process transactions, detect and prevent fraud, communicate important updates, comply with legal obligations in Kenya, and improve our platform. We do not sell your data to third parties.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Data Security</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} takes data security seriously. Passwords are hashed and never stored in plain text. Sensitive administrative data is encrypted at rest. We use HTTPS for all data transmission. However, no internet-based service can be 100% secure, and we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">5. Data Sharing</h2>
            <p className="text-muted-foreground leading-relaxed">
              We may share your data with: Safaricom (M-Pesa) and other payment processors for transaction completion, regulatory authorities when required by Kenyan law, fraud prevention services, and service providers who assist us in operating the platform (bound by confidentiality agreements).
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">6. Kenya Data Protection Act</h2>
            <p className="text-muted-foreground leading-relaxed">
              We comply with Kenya's Data Protection Act, 2019. You have the right to access your personal data, request corrections, and in certain circumstances, request deletion of your data. Contact us at {settings?.supportEmail ?? "support@zenti-investiment.vercel.app"} to exercise these rights.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">7. Data Retention</h2>
            <p className="text-muted-foreground leading-relaxed">
              We retain your data for as long as your account is active and as required by Kenyan financial regulations (typically 7 years for financial records). Upon account closure, personal data is anonymized or deleted within 90 days, except where retention is required by law.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">8. Cookies</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our platform uses essential cookies for authentication and session management. We do not use tracking or advertising cookies. You can disable cookies in your browser, but this may affect platform functionality.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">9. Contact Us</h2>
            <p className="text-muted-foreground leading-relaxed">
              For privacy-related questions or to exercise your data rights, contact our Data Protection Officer at {settings?.supportEmail ?? "support@zenti-investiment.vercel.app"} or call {settings?.contactPhone ?? "+254 700 000 000"}.
            </p>
          </section>
        </div>
      </div>
    </Layout>
  );
}
