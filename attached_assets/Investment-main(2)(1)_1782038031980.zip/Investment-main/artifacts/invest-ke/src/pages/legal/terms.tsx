import { Layout } from "@/components/layout";
import { useGetSettings } from "@workspace/api-client-react";

export default function Terms() {
  const { data: settings } = useGetSettings();
  const company = settings?.companyName ?? "Zenti";

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <h1 className="text-3xl font-bold mb-2">Terms of Service</h1>
        <p className="text-muted-foreground text-sm mb-8">Last updated: June 2026</p>

        <div className="prose prose-slate max-w-none space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              By registering on {company}, you agree to these Terms of Service in full. If you do not agree, you must not use this platform. These terms apply to all users of the platform, including investors and administrators.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. Eligibility</h2>
            <p className="text-muted-foreground leading-relaxed">
              This platform is available exclusively to Kenyan residents who are 18 years of age or older. By creating an account, you represent and warrant that you meet these eligibility requirements and that all registration information you provide is accurate and truthful.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. Mandatory Account Verification</h2>
            <p className="text-muted-foreground leading-relaxed">
              All accounts are required to be verified via a one-time password (OTP) sent to your registered phone number through WhatsApp or email before accessing any platform features. This verification is mandatory and non-negotiable. It is a core anti-fraud measure designed to protect all users on the platform. Accounts that have not completed verification will have no access to deposits, investments, withdrawals, or any other platform services. {company} reserves the right to permanently suspend any account found to have bypassed or attempted to circumvent the verification process.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Investment Plans and Returns</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} offers digital investment packages with defined daily return rates and durations. Past performance or stated return rates do not guarantee future results. Returns are credited to your wallet balance daily during the investment period. The platform reserves the right to modify plan terms with prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">5. Deposits and Withdrawals</h2>
            <p className="text-muted-foreground leading-relaxed">
              Deposits are processed via M-Pesa. Withdrawal requests are reviewed within 24 hours and processed via M-Pesa, Airtel Money, or bank transfer. The platform reserves the right to reject withdrawals if fraud or suspicious activity is detected. Minimum withdrawal amount is KES 50.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">6. Internship Package</h2>
            <p className="text-muted-foreground leading-relaxed">
              The 2-Day Internship Package is available to newly registered users during June and July 2026 only. It provides a fixed return of KES 200 over a 2-day period. Each user may activate this package only once. This offer may be withdrawn at any time without prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">7. Prohibited Activities</h2>
            <p className="text-muted-foreground leading-relaxed">
              You agree not to engage in fraudulent activities, create multiple accounts, use false identities, manipulate the platform, attempt unauthorized access, or engage in any activity that could harm the platform or other users. Violations may result in account suspension or permanent banning without refund.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">8. Account Suspension and Termination</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} reserves the right to suspend or terminate any account at its sole discretion, particularly in cases of suspected fraud, terms violation, or suspicious activity. Users will be notified by email where possible.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">9. Limitation of Liability</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} is not liable for any loss of profits, investment losses, or indirect damages arising from use of the platform. The platform provides investment tools but does not provide financial advice. Users invest at their own risk.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">10. Governing Law</h2>
            <p className="text-muted-foreground leading-relaxed">
              These terms are governed by the laws of Kenya. Any disputes shall be resolved through the courts of Kenya.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">11. Changes to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} may update these terms at any time. Continued use of the platform after changes constitutes acceptance of the new terms. Users will be notified of material changes via email or platform notification.
            </p>
          </section>
        </div>
      </div>
    </Layout>
  );
}
