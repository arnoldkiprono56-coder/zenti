import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const InitiateSchema = z.object({
  amount: z.number().min(1, "Minimum deposit is 1"),
  phone: z
    .string()
    .trim()
    .refine((value) => /^254[71]\d{8}$/.test(normalizePhone(value)), {
      message: "Enter a valid Kenyan number (07.., 01.., 2547.., or 2541..)",
    }),
});

function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.startsWith("2540")) return "254" + digits.slice(4);
  if (digits.startsWith("254")) return digits;
  if (digits.startsWith("0")) return "254" + digits.slice(1);
  if (digits.startsWith("7") || digits.startsWith("1")) return "254" + digits;
  return digits;
}

function getOrigin(): string {
  const proto =
    getRequestHeader("x-forwarded-proto") ||
    getRequestHeader("x-forwarded-protocol") ||
    "https";
  const host =
    getRequestHeader("x-forwarded-host") ||
    getRequestHeader("host") ||
    "";
  // Lovable's `id-preview--<id>.lovable.app` is auth-gated and 302-redirects
  // POSTs, so external webhooks never land. Use the stable, public preview
  // host `project--<id>-dev.lovable.app` instead.
  let publicHost = host;
  const m = host.match(/^id-preview--([0-9a-f-]+)\.lovable\.app$/i);
  if (m) publicHost = `project--${m[1]}-dev.lovable.app`;
  return `${proto}://${publicHost}`;
}

export const initiateStkPush = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InitiateSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const phone = normalizePhone(data.phone);
    const amount = Math.round(data.amount * 100) / 100;
    const externalReference = `tx_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    // Record pending transaction first (RLS allows the user to insert their own row)
    const { error: insErr } = await supabase.from("transactions").insert({
      user_id: userId,
      amount,
      phone,
      external_reference: externalReference,
      status: "pending",
    });
    if (insErr) throw new Error(`Could not create transaction: ${insErr.message}`);

    const origin = getOrigin();
    const callbackUrl = `${origin}/api/public/payhero/callback`;

    const authToken = process.env.PAYHERO_AUTH_TOKEN!;
    const channelId = Number(process.env.PAYHERO_CHANNEL_ID!);

    const payload = {
      amount,
      phone_number: phone,
      channel_id: channelId,
      provider: "m-pesa",
      external_reference: externalReference,
      customer_name: "Test User",
      callback_url: callbackUrl,
    };

    const resp = await fetch("https://backend.payhero.co.ke/api/v2/payments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: authToken.startsWith("Basic ") || authToken.startsWith("Bearer ")
          ? authToken
          : `Basic ${authToken}`,
      },
      body: JSON.stringify(payload),
    });

    const text = await resp.text();
    let json: any = null;
    try { json = JSON.parse(text); } catch { /* keep raw text */ }

    if (!resp.ok || (json && json.success === false)) {
      const reason = json?.error_message || json?.message || text || `HTTP ${resp.status}`;
      // Load admin client only when needed to mark failure (bypasses RLS for status update)
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin
        .from("transactions")
        .update({ status: "failed", result_description: String(reason).slice(0, 500) })
        .eq("external_reference", externalReference);
      throw new Error(`PayHero error: ${reason}`);
    }

    const checkoutRequestId = json?.CheckoutRequestID || json?.checkout_request_id || null;
    if (checkoutRequestId) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin
        .from("transactions")
        .update({ checkout_request_id: checkoutRequestId })
        .eq("external_reference", externalReference);
    }

    return {
      ok: true,
      externalReference,
      checkoutRequestId,
      callbackUrl,
    };
  });