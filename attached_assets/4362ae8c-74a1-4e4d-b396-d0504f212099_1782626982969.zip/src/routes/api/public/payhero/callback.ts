import { createFileRoute } from "@tanstack/react-router";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
} as const;

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

export const Route = createFileRoute("/api/public/payhero/callback")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async () => json({ ok: true, message: "PayHero callback endpoint" }),
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const raw = await request.text();
        let payload: any = {};
        try { payload = JSON.parse(raw); } catch { /* ignore */ }

        // PayHero callback shape: { response: { ExternalReference, ResultCode, Status, Amount, MpesaReceiptNumber, CheckoutRequestID, ResultDesc } }
        const r = payload?.response ?? payload ?? {};
        const externalReference: string | undefined =
          r.ExternalReference || r.external_reference || payload?.ExternalReference;
        const resultCode = Number(r.ResultCode ?? r.result_code ?? -1);
        const statusStr: string = String(r.Status ?? r.status ?? "").toLowerCase();
        const mpesaReceipt: string | null = r.MpesaReceiptNumber || r.mpesa_receipt_number || null;
        const checkoutRequestId: string | null = r.CheckoutRequestID || r.checkout_request_id || null;
        const resultDesc: string = String(r.ResultDesc ?? r.result_desc ?? r.Status ?? "").slice(0, 500);

        if (!externalReference) {
          console.error("PayHero callback missing ExternalReference", raw);
          return json({ ok: false, error: "Missing ExternalReference" }, 400);
        }

        // Find the pending transaction
        const { data: tx, error: findErr } = await supabaseAdmin
          .from("transactions")
          .select("id, user_id, amount, status")
          .eq("external_reference", externalReference)
          .maybeSingle();

        if (findErr || !tx) {
          console.error("Transaction not found", externalReference, findErr?.message);
          return json({ ok: false, error: "Transaction not found" }, 404);
        }

        const isSuccess = resultCode === 0 || statusStr === "success";
        const newStatus: "success" | "failed" = isSuccess ? "success" : "failed";

        // Idempotency — only act if still pending
        if (tx.status !== "pending") {
          return json({ ok: true, message: "Already processed" });
        }

        const { error: updErr } = await supabaseAdmin
          .from("transactions")
          .update({
            status: newStatus,
            mpesa_receipt: mpesaReceipt,
            checkout_request_id: checkoutRequestId ?? undefined,
            result_description: resultDesc,
            raw_callback: payload,
          })
          .eq("id", tx.id)
          .eq("status", "pending");

        if (updErr) {
          console.error("Failed updating transaction", updErr.message);
          return json({ ok: false, error: updErr.message }, 500);
        }

        if (isSuccess) {
          // Atomically credit the wallet
          const { data: wallet, error: wErr } = await supabaseAdmin
            .from("wallets")
            .select("balance")
            .eq("user_id", tx.user_id)
            .maybeSingle();
          if (wErr) {
            console.error("Wallet read error", wErr.message);
            return json({ ok: false, error: wErr.message }, 500);
          }
          const current = Number(wallet?.balance ?? 0);
          const next = current + Number(tx.amount);
          const { error: balErr } = await supabaseAdmin
            .from("wallets")
            .upsert({ user_id: tx.user_id, balance: next });
          if (balErr) {
            console.error("Wallet update error", balErr.message);
            return json({ ok: false, error: balErr.message }, 500);
          }
        }

        return json({ ok: true });
      },
    },
  },
});