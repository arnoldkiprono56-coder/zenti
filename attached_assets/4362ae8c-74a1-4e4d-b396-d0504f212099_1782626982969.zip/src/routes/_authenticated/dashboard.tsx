import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { initiateStkPush } from "@/lib/payhero.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — PayHero STK Test" },
      { name: "description", content: "Deposit via M-Pesa STK push and watch your balance update in real time." },
    ],
  }),
  component: Dashboard,
});

type Tx = {
  id: string;
  amount: number;
  phone: string;
  status: "pending" | "success" | "failed";
  external_reference: string;
  mpesa_receipt: string | null;
  result_description: string | null;
  created_at: string;
};

function Dashboard() {
  const navigate = useNavigate();
  const initiate = useServerFn(initiateStkPush);

  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState<string>("");
  const [balance, setBalance] = useState<number>(0);
  const [txs, setTxs] = useState<Tx[]>([]);
  const [amount, setAmount] = useState<string>("1");
  const [phone, setPhone] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  // Load user + initial data
  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      setUserId(u.user.id);
      setEmail(u.user.email ?? "");

      const { data: w } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", u.user.id)
        .maybeSingle();
      setBalance(Number(w?.balance ?? 0));

      const { data: t } = await supabase
        .from("transactions")
        .select("id, amount, phone, status, external_reference, mpesa_receipt, result_description, created_at")
        .eq("user_id", u.user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      setTxs((t ?? []) as Tx[]);
    })();
  }, []);

  // Realtime: wallet + transactions
  useEffect(() => {
    if (!userId) return;
    const channel = supabase
      .channel(`user-${userId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${userId}` },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row?.balance != null) setBalance(Number(row.balance));
        },
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "transactions", filter: `user_id=eq.${userId}` },
        (payload) => {
          setTxs((prev) => {
            const row = payload.new as Tx | undefined;
            if (!row) return prev;
            const idx = prev.findIndex((t) => t.id === row.id);
            if (idx === -1) return [row, ...prev].slice(0, 20);
            const next = [...prev];
            next[idx] = { ...next[idx], ...row };
            return next;
          });
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  async function onDeposit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt < 1) {
      setMsg({ type: "err", text: "Minimum deposit is 1" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await initiate({ data: { amount: amt, phone } });
      setMsg({ type: "ok", text: `STK push sent. Check your phone. Ref: ${res.externalReference}` });
    } catch (err: any) {
      setMsg({ type: "err", text: err?.message ?? "Failed to initiate STK push" });
    } finally {
      setSubmitting(false);
    }
  }

  async function onSignOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="mx-auto w-full max-w-2xl space-y-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">PayHero STK Test</h1>
            <p className="text-sm text-muted-foreground">{email}</p>
          </div>
          <button
            onClick={onSignOut}
            className="rounded-md border border-input bg-background px-3 py-1.5 text-sm hover:bg-accent"
          >
            Sign out
          </button>
        </header>

        <section className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <p className="text-sm text-muted-foreground">Balance</p>
          <p className="mt-1 text-4xl font-bold tabular-nums">
            KES {balance.toFixed(2)}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">Updates live via Realtime when the callback hits.</p>
        </section>

        <section className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h2 className="text-lg font-semibold">Deposit (M-Pesa)</h2>
          <form onSubmit={onDeposit} className="mt-4 space-y-3">
            <div>
              <label className="block text-sm font-medium">Phone</label>
              <input
                type="tel"
                required
                placeholder="07XXXXXXXX, 01XXXXXXXX, or 2547XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium">Amount (KES, min 1)</label>
              <input
                type="number"
                required
                min={1}
                step="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              />
            </div>
            {msg && (
              <p className={`text-sm ${msg.type === "ok" ? "text-emerald-600" : "text-destructive"}`}>{msg.text}</p>
            )}
            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-60"
            >
              {submitting ? "Sending STK push…" : "Send STK push"}
            </button>
          </form>
        </section>

        <section className="rounded-xl border border-border bg-card p-6 shadow-sm">
          <h2 className="text-lg font-semibold">Recent transactions</h2>
          <div className="mt-4 divide-y divide-border">
            {txs.length === 0 && (
              <p className="text-sm text-muted-foreground">No transactions yet.</p>
            )}
            {txs.map((t) => (
              <div key={t.id} className="flex items-start justify-between gap-3 py-3 text-sm">
                <div className="min-w-0">
                  <p className="font-medium tabular-nums">KES {Number(t.amount).toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">{t.phone}</p>
                  {t.mpesa_receipt && (
                    <p className="text-xs text-muted-foreground">Receipt: {t.mpesa_receipt}</p>
                  )}
                  {t.result_description && t.status !== "success" && (
                    <p className="text-xs text-muted-foreground truncate">{t.result_description}</p>
                  )}
                </div>
                <span
                  className={
                    "rounded-full px-2 py-0.5 text-xs font-medium " +
                    (t.status === "success"
                      ? "bg-emerald-100 text-emerald-700"
                      : t.status === "failed"
                      ? "bg-red-100 text-red-700"
                      : "bg-amber-100 text-amber-700")
                  }
                >
                  {t.status}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}