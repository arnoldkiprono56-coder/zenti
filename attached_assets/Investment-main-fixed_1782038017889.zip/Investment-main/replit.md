# InvestKE / Zenti

A Kenya-focused digital investment platform where users deposit via M-Pesa, earn daily returns on plans, and withdraw to M-Pesa/Airtel Money/Bank. Features a superadmin dashboard and a 2-day internship package for new users (June–July 2026).

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, also served at /api via proxy)
- `pnpm --filter @workspace/invest-ke run dev` — run the frontend (port 25538, served at /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — JWT signing secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5, JWT auth (stored in localStorage as `investke_token`)
- DB: PostgreSQL + Drizzle ORM
- Frontend: React + Vite + TanStack Query + shadcn/ui + Tailwind CSS
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — source of truth for all API contracts
- `lib/api-client-react/src/generated/api.ts` — generated hooks (do not edit manually)
- `lib/db/src/schema/index.ts` — Drizzle ORM schema (source of truth for DB)
- `artifacts/api-server/src/` — Express backend (routes, middlewares, app)
- `artifacts/invest-ke/src/` — React frontend (pages, components, hooks)
- `artifacts/api-server/src/lib/whatsapp.ts` — WhatsApp bot client (OTP + notifications)

## Architecture decisions

- JWT is stored in localStorage under `investke_token`; `setAuthTokenGetter()` is called once at app startup in `use-auth.ts` to inject the token into every API call
- All routes follow OpenAPI contract-first: edit `openapi.yaml`, run codegen, then implement in Express
- Plans store financial amounts as `numeric(14,2)` in DB (string in Drizzle); `serializePlan()` parses them to floats for the API response
- `superadmin` role is seeded only; the admin dashboard only allows promoting users to `admin` (not `superadmin`)
- The admin GET `/api/admin/settings` is public (unauthenticated) so the frontend can load platform name/contact info on landing pages
- WhatsApp notifications are all fire-and-forget (async IIFE + try/catch) — gateway failures never block the main response

## WhatsApp OTP Bot (Railway)

The platform sends OTPs and user notifications via a personal WhatsApp account running on [Railway](https://railway.app). It uses [Baileys](https://github.com/WhiskeySockets/Baileys) with **pairing-code** login — no QR scanning needed.

### Deploy the bot to Railway

1. Push the `railway-bot/` folder to a new GitHub repo (or use Railway's "Deploy from GitHub" with this subfolder as root).
2. In Railway: **New Project → Deploy from Repo**. Set **Root Directory** to `railway-bot` if it lives in a monorepo.
3. Add a **Persistent Volume** mounted at `/app/auth_session` so the WhatsApp session survives restarts. Without it you'll have to re-pair on every deploy.
4. Set these environment variables in Railway:
   - `SHARED_SECRET` — a long random string (must match `BOT_SHARED_SECRET` in the main app)
   - `PHONE_NUMBER` — the WhatsApp number in E.164 without `+`, e.g. `254712345678`
   - `PORT` is set automatically by Railway
5. Deploy and open the **Logs** tab.

### Pair your phone

After deploy the logs will print a pairing code:

```
==================================================
 WhatsApp Pairing Code: ABCD-EF12
 Phone:                 +254712345678
 Open WhatsApp on your phone:
  Settings -> Linked Devices -> Link a device
  -> Link with phone number instead -> enter this code
==================================================
```

On your phone: **WhatsApp → Settings → Linked Devices → Link a device → "Link with phone number instead" → enter the 8-character code.**

Once paired, logs show `[CONN] Connected as ...` and `GET /status` returns `connected: true`. The bot auto-reconnects on disconnects.

### Connect to the main app

Set these two secrets in the Replit project (Secrets panel or `.env`):

| Secret | Value |
|---|---|
| `BOT_BASE_URL` | Your Railway public URL, e.g. `https://otp-bot.up.railway.app` |
| `BOT_SHARED_SECRET` | Same value as `SHARED_SECRET` set in Railway |

Also add both to Vercel Environment Variables when deploying.

### Bot API contract

The API server talks to the bot via:

```
GET  {BOT_BASE_URL}/status
     Header: x-bot-secret: <BOT_SHARED_SECRET>
     Response: { connected: boolean }

POST {BOT_BASE_URL}/send-otp
     Header: x-bot-secret: <BOT_SHARED_SECRET>
     Body:   { phone: string, code: string }
     Response: { ok: boolean, delivered: boolean, error?: string }

POST {BOT_BASE_URL}/send-message
     Header: x-bot-secret: <BOT_SHARED_SECRET>
     Body:   { phone: string, text: string }
     Response: { ok: boolean, delivered: boolean, error?: string }
```

### WhatsApp notifications sent by the platform

| Trigger | Message |
|---|---|
| User registers | Welcome message with getting-started guide |
| OTP send fails | Amber warning in OTP dialog — code still works |
| M-Pesa deposit confirmed | Receipt with amount + new wallet balance |
| Investment started | Plan name, daily earning, expected total, maturity date |
| Internship package activated | Fixed earning + completion date |
| Withdrawal requested | Amount, method, account, timestamp |
| Withdrawal approved | Amount + new balance |
| Withdrawal rejected | Reason for rejection |
| Daily earning credited | Amount earned today + new balance |
| Investment completed/matured | Total earned + wallet balance + prompt to reinvest |

### Local test

```bash
cd railway-bot
npm install
SHARED_SECRET=devsecret PHONE_NUMBER=254712345678 npm start
```

## Product

- **Landing page** — hero section, plan previews, M-Pesa integration highlights
- **Auth** — register (Kenyan phone required), login, JWT session
- **Dashboard** — wallet balance, active investments with progress, recent transactions, internship package banner
- **Invest** — browse plans, deposit via M-Pesa (STK push), create investments
- **Transactions** — full history with type/status filters
- **Withdraw** — request withdrawal to M-Pesa, Airtel Money, or Bank
- **Support** — contact form with subject/message
- **Legal** — Terms of Service, Privacy Policy pages
- **Admin dashboard** — stats overview, user management, plan CRUD, transaction approval/rejection, activity logs, fraud flags, support requests, platform settings, WhatsApp bot status

## Seed data (already applied)

| Account | Email | Password |
|---|---|---|
| Super Admin | admin@investke.co.ke | Admin@1234! |
| Test User | test@investke.co.ke | Test@1234! |

Plans: Starter (3%/7d, min KES 500), Silver (5%/14d, min KES 5k), Gold (7.5%/21d, min KES 25k), Platinum (10%/30d, min KES 100k), Internship Package (fixed KES 200/2d)

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Vercel Deployment

The project uses **Vercel Build Output API v3** for full-control deployment.

### How it works
- `vercel.json` tells Vercel to run `node scripts/build-vercel.mjs` as the build command
- The build script produces `.vercel/output/` with:
  - `static/` — the built React frontend (served as CDN)
  - `functions/api.func/` — the Express API bundled as an ESM serverless function
  - `config.json` — routing: `/api/*` → serverless, everything else → SPA fallback
- The frontend calls `/api/*` on the same domain — no `VITE_API_URL` needed

### Steps to deploy on Vercel
1. Push the repo to GitHub
2. Import the repo in [vercel.com](https://vercel.com) — set **Root Directory** to `.` (repo root)
3. Vercel auto-detects `vercel.json`; the install/build commands are preconfigured
4. Add these **Environment Variables** in the Vercel project settings:
   - `DATABASE_URL` — PostgreSQL connection string (e.g. from [Neon](https://neon.tech), [Supabase](https://supabase.com), or [Railway](https://railway.app))
   - `SESSION_SECRET` — any long random string for JWT signing
   - `BOT_BASE_URL` — your Railway bot public URL
   - `BOT_SHARED_SECRET` — shared secret matching the bot's `SHARED_SECRET`
5. Deploy — Vercel runs `pnpm install --frozen-lockfile` then `node scripts/build-vercel.mjs`

### Run build locally (test before pushing)
```bash
pnpm build:vercel
```
Output goes to `.vercel/output/` (gitignored).

## Gotchas

- **Always restart the API server workflow after changing backend code** — the dev script runs `build && start`, so changes only take effect after a restart
- **To re-seed the DB**: use `psql "$DATABASE_URL"` directly with SQL — tsx/node in /tmp can't resolve workspace packages
- **Admin password reset**: generate hash with `node -e "const b=require('bcryptjs'); b.hash('pass',10).then(console.log)"` from `artifacts/api-server/` directory, then update via psql
- **`useGetMe` query options**: pass `as any` to work around TanStack Query v5's strict `queryKey` requirement in `UseQueryOptions`
- **The proxy routes /api to the API server**: never call `localhost:8080` directly in curl tests; always use `localhost:80/api/...`
- **WhatsApp secrets renamed**: old `WHATSAPP_GATEWAY_URL` → `BOT_BASE_URL`, old `WHATSAPP_BOT_SECRET` → `BOT_SHARED_SECRET`. Update both in Replit Secrets and Vercel.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
