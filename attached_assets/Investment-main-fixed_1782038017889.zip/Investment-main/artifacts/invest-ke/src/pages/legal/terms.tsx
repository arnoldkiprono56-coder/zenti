import { Layout } from "@/components/layout";
import { useGetSettings } from "@workspace/api-client-react";

export default function Terms() {
  const { data: settings } = useGetSettings();
  const company = settings?.companyName ?? "Zenti";

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <h1 className="text-3xl font-bold mb-2">Terms of Service</h1>
        <p className="text-muted-foreground text-sm mb-8">Last updated: June 2026</p>

        <div className="prose prose-slate max-w-none space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              By registering on {company}, you agree to these Terms of Service in full. If you do not agree, you must not use this platform. These terms apply to all users of the platform, including investors and administrators.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">2. Eligibility</h2>
            <p className="text-muted-foreground leading-relaxed">
              This platform is available exclusively to Kenyan residents who are 18 years of age or older. By creating an account, you represent and warrant that you meet these eligibility requirements and that all registration information you provide is accurate and truthful.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">3. Mandatory Account Verification</h2>
            <p className="text-muted-foreground leading-relaxed">
              All accounts must be verified via a one-time password (OTP) sent to your registered phone number through WhatsApp or email before accessing any platform features. This verification is mandatory and non-negotiable. Accounts that have not completed verification will have no access to deposits, investments, withdrawals, or any other platform services. {company} reserves the right to permanently suspend any account found to have bypassed or attempted to circumvent the verification process.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">4. Investment Plans and Returns</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} offers digital investment packages with defined daily return rates and durations. Past performance or stated return rates do not guarantee future results. Returns are credited to your wallet balance daily during the investment period. The platform reserves the right to modify plan terms with prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">5. Deposits</h2>
            <p className="text-muted-foreground leading-relaxed">
              Deposits are processed via M-Pesa through PayHero. Funds are credited to your in-platform wallet upon confirmation by the payment provider. Deposits, once credited, can only be used to activate investment plans on the platform.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">6. Withdrawal Rules &mdash; IMPORTANT</h2>
            <p className="text-muted-foreground leading-relaxed">
              All accumulated earnings on {company} are <strong>locked by default</strong>. To withdraw any portion of your balance you must satisfy <strong>all</strong> of the following conditions:
            </p>
            <ul className="list-disc pl-6 mt-3 space-y-2 text-muted-foreground leading-relaxed">
              <li>You have an <strong>active, funded investment plan</strong> (the internship package does not count).</li>
              <li>It is the <strong>final day</strong> of that ongoing investment (for example, on day 7 of a 7-day plan). Withdrawals are blocked on every other day.</li>
              <li>You have <strong>deposited and activated a new plan since your most recent withdrawal</strong>. Activating a new plan does not immediately release funds &mdash; the lock applies again until that plan reaches its final day.</li>
              <li>Minimum withdrawal: <strong>KES 200</strong>. A processing fee (configured by the platform) is deducted from the gross withdrawal.</li>
              <li>One withdrawal per cooldown window, subject to the daily limit, and a holding period applies after every deposit.</li>
              <li>Withdrawals are paid out to M-Pesa, Airtel Money, or bank transfer and are reviewed within 24 hours. Requests showing suspected fraud or abuse will be rejected and the account may be suspended.</li>
            </ul>
            <p className="text-muted-foreground leading-relaxed mt-3">
              By using {company} you acknowledge that these withdrawal rules are part of the platform&apos;s anti-fraud and reinvestment model and apply to every user without exception.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">7. Internship Package</h2>
            <p className="text-muted-foreground leading-relaxed">
              The 2-Day Internship Package is available to newly registered users during the eligibility window configured by the platform (currently June&ndash;July 2026). It provides a fixed total return paid over 2 days and may be activated only once per user. Internship earnings count toward your wallet balance but, like all other earnings, are subject to the withdrawal rules in Section 6 &mdash; the internship itself is not a funded plan and does not unlock withdrawals on its own. This offer may be withdrawn at any time without prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">8. Prohibited Activities</h2>
            <p className="text-muted-foreground leading-relaxed">
              You agree not to engage in fraudulent activities, create multiple accounts, use false identities, manipulate the platform, attempt unauthorized access, or engage in any activity that could harm the platform or other users. Violations may result in account suspension or permanent banning without refund.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">9. Account Suspension and Termination</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} reserves the right to suspend or terminate any account at its sole discretion, particularly in cases of suspected fraud, terms violation, or suspicious activity. Users will be notified by email where possible.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">10. Limitation of Liability</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} is not liable for any loss of profits, investment losses, or indirect damages arising from use of the platform. The platform provides investment tools but does not provide financial advice. Users invest at their own risk.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">11. Governing Law</h2>
            <p className="text-muted-foreground leading-relaxed">
              These terms are governed by the laws of Kenya. Any disputes shall be resolved through the courts of Kenya.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3">12. Changes to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              {company} may update these terms at any time. Continued use of the platform after changes constitutes acceptance of the new terms. Users will be notified of material changes via email or platform notification.
            </p>
          </section>
        </div>
      </div>
    </Layout>
  );
}
