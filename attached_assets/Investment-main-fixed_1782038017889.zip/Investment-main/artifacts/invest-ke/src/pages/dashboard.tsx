import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useGetDashboardSummary, useGetMyInvestments, useGetMyTransactions, useActivateInternship, getGetDashboardSummaryQueryKey, getGetMyInvestmentsQueryKey } from "@workspace/api-client-react";
import { formatKES, formatDate } from "@/lib/format";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  TrendingUp, Wallet, ArrowDownToLine, ArrowUpFromLine,
  Clock, CheckCircle2, Gift, Zap, Users,
  ArrowUpRight, ArrowDownLeft, Sparkles,
} from "lucide-react";

const txnIcon: Record<string, React.ReactNode> = {
  deposit:    <ArrowUpRight   className="h-4 w-4 text-green-600" />,
  withdrawal: <ArrowDownLeft  className="h-4 w-4 text-red-500"   />,
  earning:    <Sparkles       className="h-4 w-4 text-primary"   />,
};
const txnColor: Record<string, string> = {
  deposit:    "text-green-600",
  withdrawal: "text-red-500",
  earning:    "text-primary",
};

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: summary, isLoading: summaryLoading } = useGetDashboardSummary();
  const { data: investments = [], isLoading: invLoading } = useGetMyInvestments();
  const { data: transactions = [] } = useGetMyTransactions();
  const activateInternship = useActivateInternship({
    mutation: {
      onSuccess: () => {
        toast({ title: "Internship package activated!", description: "You will earn KES 200 over the next 2 days." });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMyInvestmentsQueryKey() });
      },
      onError: (e: { data?: { error?: string } }) => {
        toast({ title: "Error", description: e.data?.error ?? "Could not activate", variant: "destructive" });
      }
    }
  });

  const activeInvestments = investments.filter(i => i.status === "active");
  const recentTransactions = transactions.slice(0, 6);

  return (
    <Layout requireAuth>
      <div className="container mx-auto px-4 py-6 max-w-5xl">

        {/* Greeting + action buttons */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Hi, {user?.fullName?.split(" ")[0]} 👋</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Here's your investment overview</p>
        </div>

        {/* Action buttons — full width on mobile, inline on desktop */}
        <div className="grid grid-cols-2 sm:flex sm:flex-row gap-3 mb-6">
          <Link href="/invest" className="contents">
            <Button className="w-full sm:w-auto gap-2">
              <ArrowUpFromLine className="h-4 w-4" /> Deposit & Invest
            </Button>
          </Link>
          <Link href="/withdraw" className="contents">
            <Button variant="outline" className="w-full sm:w-auto gap-2">
              <ArrowDownToLine className="h-4 w-4" /> Withdraw
            </Button>
          </Link>
          <Link href="/referrals" className="contents">
            <Button variant="ghost" className="w-full sm:w-auto gap-2 col-span-2 sm:col-span-1 border border-dashed">
              <Users className="h-4 w-4" /> Invite & Earn
            </Button>
          </Link>
        </div>

        {/* Internship Banner */}
        {user?.isInternshipEligible && !user?.internshipActivated && (
          <div className="mb-5 rounded-xl border-2 border-primary/30 bg-primary/5 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 p-2 rounded-lg shrink-0">
                <Gift className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-primary text-sm">2-Day Internship Package Available</p>
                <p className="text-xs text-muted-foreground">Earn KES 200 over 2 days — for new members this June & July</p>
              </div>
            </div>
            <Button size="sm" onClick={() => activateInternship.mutate()} disabled={activateInternship.isPending} className="shrink-0 w-full sm:w-auto">
              {activateInternship.isPending ? "Activating..." : "Activate Now"}
            </Button>
          </div>
        )}

        {/* Internship Progress */}
        {user?.internshipActivated && summary?.internshipProgress !== null && summary?.internshipProgress !== undefined && (
          <div className="mb-5 rounded-xl border border-primary/20 bg-primary/5 p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-primary" />
                <span className="font-semibold text-primary text-sm">Internship Progress</span>
              </div>
              <span className="text-sm font-bold text-primary">{summary.internshipProgress.toFixed(1)}%</span>
            </div>
            <Progress value={summary.internshipProgress} className="h-2.5" />
            <p className="text-xs text-muted-foreground mt-1.5">2-day package running — KES 200 total target.</p>
          </div>
        )}

        {/* KPI Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {summaryLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i}><CardContent className="p-4"><Skeleton className="h-10 w-full" /></CardContent></Card>
            ))
          ) : (
            <>
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1"><Wallet className="h-3.5 w-3.5" />Balance</div>
                  <p className="text-xl font-bold text-primary">{formatKES(summary?.balance ?? 0)}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1"><TrendingUp className="h-3.5 w-3.5" />Total Earned</div>
                  <p className="text-xl font-bold text-green-600">{formatKES(summary?.totalEarned ?? 0)}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1"><Sparkles className="h-3.5 w-3.5" />Today</div>
                  <p className="text-xl font-bold">{formatKES(summary?.todayEarnings ?? 0)}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs mb-1"><CheckCircle2 className="h-3.5 w-3.5" />Active Plans</div>
                  <p className="text-xl font-bold">{summary?.activeInvestments ?? 0}</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
          {/* Active Investments — wider col */}
          <Card className="lg:col-span-3">
            <CardHeader className="flex flex-row items-center justify-between pb-3 pt-4 px-5">
              <CardTitle className="text-sm font-semibold">Active Investments</CardTitle>
              <Link href="/invest">
                <Button variant="ghost" size="sm" className="h-7 text-xs">+ Invest More</Button>
              </Link>
            </CardHeader>
            <CardContent className="px-5 pb-5">
              {invLoading ? (
                <div className="space-y-3"><Skeleton className="h-20 w-full" /><Skeleton className="h-20 w-full" /></div>
              ) : activeInvestments.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  <TrendingUp className="h-9 w-9 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No active investments yet</p>
                  <Link href="/invest">
                    <Button size="sm" className="mt-3">Start Investing</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {activeInvestments.map(inv => (
                    <div key={inv.id} className="rounded-xl border bg-muted/20 p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <p className="font-semibold text-sm">{inv.plan?.name ?? "Investment Plan"}</p>
                          <p className="text-xs text-muted-foreground">{formatKES(inv.amountInvested)} invested</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600 text-sm">+{formatKES(inv.dailyEarning ?? 0)}<span className="font-normal text-muted-foreground text-xs">/day</span></p>
                          <p className="text-xs text-muted-foreground">{formatKES(inv.totalEarned)} earned</p>
                        </div>
                      </div>
                      <Progress value={inv.progressPercent ?? 0} className="h-1.5" />
                      <div className="flex justify-between mt-1.5">
                        <p className="text-xs text-muted-foreground">{(inv.progressPercent ?? 0).toFixed(1)}% complete</p>
                        <Badge variant="secondary" className="text-xs h-4">Active</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Transactions — narrower col */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between pb-3 pt-4 px-5">
              <CardTitle className="text-sm font-semibold">Recent Activity</CardTitle>
              <Link href="/transactions">
                <Button variant="ghost" size="sm" className="h-7 text-xs">View All</Button>
              </Link>
            </CardHeader>
            <CardContent className="px-5 pb-5">
              {recentTransactions.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">No transactions yet</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {recentTransactions.map(txn => (
                    <div key={txn.id} className="flex items-center gap-3 py-2.5 border-b last:border-0">
                      <div className="bg-muted rounded-full p-1.5 shrink-0">
                        {txnIcon[txn.type] ?? <Sparkles className="h-4 w-4 text-muted-foreground" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium capitalize leading-tight">{txn.type}</p>
                        <p className="text-xs text-muted-foreground truncate">{formatDate(String(txn.createdAt))}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className={`font-semibold text-sm ${txnColor[txn.type] ?? "text-foreground"}`}>
                          {txn.type === "withdrawal" ? "−" : "+"}{formatKES(txn.amount)}
                        </p>
                        <span className={`text-xs ${txn.status === "completed" ? "text-green-600" : txn.status === "pending" ? "text-yellow-600" : "text-red-500"}`}>
                          {txn.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
