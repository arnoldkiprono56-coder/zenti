// CJS entry point for IIS iisnode on SmarterASP.NET
// iisnode sets PORT to a named pipe path; we pass it straight to Express
"use strict";
const { pathToFileURL } = require("url");
const path = require("path");

const entry = pathToFileURL(path.join(__dirname, "dist", "index.mjs")).href;

import(entry).catch((err) => {
  console.error("Server failed to start:", err);
  process.exit(1);
});
