import nodemailer from "nodemailer";

/* ─── Types ─────────────────────────────────────────────────────────────── */

export interface SmtpConfig {
  host: string;
  port: number;
  user: string;
  pass: string;
  fromEmail: string;
  fromName: string;
}

export interface EmailResult {
  ok: boolean;
  delivered: boolean;
  error?: string;
}

export interface EmailOtpPayload {
  email: string;
  code: string;
  reason?: string;
  name?: string;
}

export interface EmailNotificationPayload {
  email: string;
  name?: string;
  subject: string;
  heading: string;
  body: string;
  icon?: string;
}

/* ─── Config helper ──────────────────────────────────────────────────────── */

export function getDefaultSmtpConfig(settings?: {
  smtpHost?: string | null;
  smtpPort?: string | null;
  smtpFromEmail?: string | null;
  smtpFromName?: string | null;
} | null): SmtpConfig {
  const user = process.env["SMTP_USER"] ?? "";
  const pass = process.env["SMTP_PASS"] ?? "";
  return {
    host: settings?.smtpHost ?? "smtp.gmail.com",
    port: parseInt(settings?.smtpPort ?? "587", 10) || 587,
    user,
    pass,
    fromEmail: settings?.smtpFromEmail || user,
    fromName: settings?.smtpFromName ?? "Zenti",
  };
}

/* ─── Internal helpers ───────────────────────────────────────────────────── */

function fmt(amount: number): string {
  return `KES ${amount.toLocaleString("en-KE", { minimumFractionDigits: 2 })}`;
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString("en-KE", {
    timeZone: "Africa/Nairobi",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function buildTransporter(cfg: SmtpConfig) {
  return nodemailer.createTransport({
    host: cfg.host,
    port: cfg.port,
    secure: cfg.port === 465,
    auth: { user: cfg.user, pass: cfg.pass },
  });
}

async function send(cfg: SmtpConfig, to: string, subject: string, html: string, text: string): Promise<EmailResult> {
  if (!cfg.user || !cfg.pass) return { ok: false, delivered: false, error: "SMTP credentials not configured" };
  if (!to) return { ok: false, delivered: false, error: "Recipient email is required" };
  try {
    await buildTransporter(cfg).sendMail({ from: `"${cfg.fromName}" <${cfg.fromEmail}>`, to, subject, html, text });
    return { ok: true, delivered: true };
  } catch (err) {
    return { ok: false, delivered: false, error: err instanceof Error ? err.message : "Email send failed" };
  }
}

/* ─── HTML Layout ────────────────────────────────────────────────────────── */

function layout(fromName: string, body: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0"/><title>${fromName}</title></head>
<body style="margin:0;padding:0;background:#f0fdf4;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0fdf4;padding:36px 0;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.09);max-width:560px;">
        <tr>
          <td style="background:linear-gradient(135deg,#14532d 0%,#16a34a 100%);padding:32px 40px;text-align:center;">
            <h1 style="margin:0;color:#ffffff;font-size:26px;font-weight:800;letter-spacing:-0.5px;">${fromName}</h1>
            <p style="margin:6px 0 0;color:#bbf7d0;font-size:13px;">Kenya's Smart Investment Platform</p>
          </td>
        </tr>
        <tr><td style="padding:36px 40px;">${body}</td></tr>
        <tr>
          <td style="background:#f7fdf9;padding:16px 40px;text-align:center;border-top:1px solid #d1fae5;">
            <p style="margin:0 0 4px;color:#6b7280;font-size:12px;">Questions? <a href="mailto:support@investke.co.ke" style="color:#16a34a;text-decoration:none;">support@investke.co.ke</a></p>
            <p style="margin:0;color:#9ca3af;font-size:11px;">&copy; 2026 ${fromName}. All rights reserved. Nairobi, Kenya.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

function row(label: string, value: string, highlight = false): string {
  const vs = highlight
    ? "padding:10px 0;border-bottom:1px solid #d1fae5;font-weight:700;color:#14532d;text-align:right;font-size:14px;"
    : "padding:10px 0;border-bottom:1px solid #f0fdf4;text-align:right;color:#374151;font-size:14px;";
  return `<tr><td style="padding:10px 0;border-bottom:1px solid #f0fdf4;color:#6b7280;font-size:14px;">${label}</td><td style="${vs}">${value}</td></tr>`;
}

function table(rows: string): string {
  return `<table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:20px 0;">${rows}</table>`;
}

function cta(text: string, url = "https://zenti-investiment.vercel.app"): string {
  return `<table width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0 8px;"><tr><td align="center"><a href="${url}" style="display:inline-block;background:linear-gradient(135deg,#14532d,#16a34a);color:#ffffff;text-decoration:none;padding:14px 36px;border-radius:8px;font-weight:700;font-size:15px;">${text}</a></td></tr></table>`;
}

function hero(icon: string, text: string, bg = "#f0fdf4", color = "#14532d"): string {
  return `<div style="background:${bg};border-radius:10px;padding:18px;text-align:center;margin:20px 0;"><div style="font-size:36px;margin-bottom:8px;">${icon}</div><div style="font-size:16px;font-weight:700;color:${color};">${text}</div></div>`;
}

function hi(name?: string): string {
  return `<p style="margin:0 0 16px;color:#111827;font-size:15px;">Hi <strong>${name ?? "there"}</strong>,</p>`;
}

function para(text: string): string {
  return `<p style="margin:0 0 16px;color:#374151;font-size:15px;line-height:1.7;">${text}</p>`;
}

function hr(): string {
  return `<hr style="border:none;border-top:1px solid #d1fae5;margin:24px 0;"/>`;
}

function note(text: string): string {
  return `<p style="margin:0;color:#9ca3af;font-size:12px;text-align:center;line-height:1.6;">${text}</p>`;
}

function tip(text: string): string {
  return `<div style="background:#fefce8;border:1px solid #fde68a;border-radius:10px;padding:14px 18px;margin:16px 0;"><p style="margin:0;color:#92400e;font-size:14px;line-height:1.6;">💡 ${text}</p></div>`;
}

function alert(text: string, bg = "#fef2f2", border = "#fecaca", color = "#7f1d1d"): string {
  return `<div style="background:${bg};border:1px solid ${border};border-radius:10px;padding:14px 18px;margin:16px 0;"><p style="margin:0;color:${color};font-size:14px;line-height:1.6;">${text}</p></div>`;
}

/* ─── OTP Email ──────────────────────────────────────────────────────────── */

export async function sendEmailOtp(payload: EmailOtpPayload, smtpConfig?: SmtpConfig): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const reason = payload.reason ?? "Verification";
  const body = `
    ${hi(payload.name)}
    ${para(`Your verification code for <strong>${reason}</strong> is:`)}
    <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:8px 0 24px;">
      <div style="display:inline-block;background:#f0fdf4;border:2px solid #16a34a;border-radius:14px;padding:20px 52px;">
        <span style="font-size:42px;font-weight:900;letter-spacing:14px;color:#14532d;font-family:'Courier New',monospace;">${payload.code}</span>
      </div>
    </td></tr></table>
    <p style="margin:0 0 4px;color:#6b7280;font-size:13px;text-align:center;">Expires in <strong>5 minutes</strong>. Never share it with anyone.</p>
    ${hr()}${note("If you didn't request this code, you can safely ignore this email.")}`;
  return send(cfg, payload.email, `${payload.code} — Your ${cfg.fromName} Verification Code`, layout(cfg.fromName, body),
    `Your ${cfg.fromName} verification code for ${reason} is: ${payload.code}\n\nExpires in 5 minutes. Do not share.`);
}

/* ─── Generic notification (used by admin routes) ────────────────────────── */

export async function sendEmailNotification(payload: EmailNotificationPayload, smtpConfig?: SmtpConfig): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const body = `
    <div style="font-size:36px;text-align:center;margin-bottom:12px;">${payload.icon ?? "📬"}</div>
    <h2 style="margin:0 0 20px;color:#111827;font-size:19px;text-align:center;">${payload.heading}</h2>
    <div style="color:#374151;font-size:15px;line-height:1.7;">${payload.body}</div>`;
  return send(cfg, payload.email, payload.subject, layout(cfg.fromName, body), payload.body.replace(/<[^>]+>/g, ""));
}

/* ─── SMTP Test ──────────────────────────────────────────────────────────── */

export async function testSmtpConnection(config: { host: string; port: number; user: string; pass: string }): Promise<{ ok: boolean; error?: string }> {
  try {
    await nodemailer.createTransport({ host: config.host, port: config.port, secure: config.port === 465, auth: { user: config.user, pass: config.pass } }).verify();
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "Connection failed" };
  }
}

/* ─── Welcome ────────────────────────────────────────────────────────────── */

export async function sendWelcomeEmail(user: { email: string; name: string }, smtpConfig?: SmtpConfig): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const body = `
    ${hi(user.name)}
    ${hero("🎉", `Welcome to ${cfg.fromName}!`)}
    ${para("Your account has been created successfully. You're now part of Kenya's fastest-growing investment community.")}
    <p style="margin:0 0 8px;color:#111827;font-size:14px;font-weight:600;">Here's how to start earning:</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px;">
      <tr><td style="padding:8px 0;"><span style="display:inline-block;background:#16a34a;color:#fff;border-radius:50%;width:24px;height:24px;text-align:center;line-height:24px;font-size:12px;font-weight:700;margin-right:10px;vertical-align:middle;">1</span><span style="color:#374151;font-size:14px;vertical-align:middle;">Activate your free <strong>Internship Package</strong> — earn KES 200 in 2 days, no deposit needed.</span></td></tr>
      <tr><td style="padding:8px 0;"><span style="display:inline-block;background:#16a34a;color:#fff;border-radius:50%;width:24px;height:24px;text-align:center;line-height:24px;font-size:12px;font-weight:700;margin-right:10px;vertical-align:middle;">2</span><span style="color:#374151;font-size:14px;vertical-align:middle;">Deposit via <strong>M-Pesa</strong> and choose an investment plan.</span></td></tr>
      <tr><td style="padding:8px 0;"><span style="display:inline-block;background:#16a34a;color:#fff;border-radius:50%;width:24px;height:24px;text-align:center;line-height:24px;font-size:12px;font-weight:700;margin-right:10px;vertical-align:middle;">3</span><span style="color:#374151;font-size:14px;vertical-align:middle;">Earn <strong>daily returns</strong> and withdraw to M-Pesa, Airtel Money, or Bank.</span></td></tr>
    </table>
    ${cta("🚀 Start Earning Now")}${hr()}${note("You received this because you created a Zenti account.")}`;
  return send(cfg, user.email, `🎉 Welcome to ${cfg.fromName} — Start Earning Today!`, layout(cfg.fromName, body),
    `Welcome to ${cfg.fromName}, ${user.name}! Activate your free Internship Package and start earning.`);
}

/* ─── Deposit Confirmed ──────────────────────────────────────────────────── */

export async function sendDepositConfirmedEmail(
  user: { email: string; name: string },
  data: { amount: number; newBalance: number; reference?: string | null; method?: string },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
  const rows = [
    row("Amount Deposited", fmt(data.amount), true),
    row("Method", data.method ?? "M-Pesa"),
    ...(data.reference ? [row("Reference", data.reference)] : []),
    row("New Wallet Balance", fmt(data.newBalance), true),
    row("Time", time),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("💰", `${fmt(data.amount)} Deposit Received`)}
    ${para("Your M-Pesa deposit has been received and credited to your Zenti wallet instantly.")}
    ${table(rows)}
    ${para("Ready to invest? Browse our plans and start earning daily returns.")}
    ${cta("💼 Browse Investment Plans")}${hr()}${note("If you did not make this deposit, contact support immediately.")}`;
  return send(cfg, user.email, `💰 Deposit Confirmed — ${fmt(data.amount)} credited to your wallet`, layout(cfg.fromName, body),
    `Your deposit of ${fmt(data.amount)} is confirmed. New balance: ${fmt(data.newBalance)}.`);
}

/* ─── Investment Started ─────────────────────────────────────────────────── */

export async function sendInvestmentStartedEmail(
  user: { email: string; name: string },
  data: { planName: string; amountInvested: number; dailyEarning: number; expectedTotal: number; completesAt: Date },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const rows = [
    row("Plan", `<strong>${data.planName}</strong>`),
    row("Amount Invested", fmt(data.amountInvested), true),
    row("Daily Earning", fmt(data.dailyEarning)),
    row("Total Expected", fmt(data.expectedTotal), true),
    row("Matures On", fmtDate(data.completesAt)),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("📈", "Your Investment Is Now Active!")}
    ${para(`Your investment in the <strong>${data.planName}</strong> plan is live and earning.`)}
    ${table(rows)}
    ${para("Your daily earnings will be credited to your wallet automatically each day. Sit back and watch your money grow!")}
    ${cta("📊 Track My Investment")}${hr()}${note("Early withdrawals are not permitted. Funds mature on the date shown above.")}`;
  return send(cfg, user.email, `📈 Investment Active — ${fmt(data.amountInvested)} in ${data.planName}`, layout(cfg.fromName, body),
    `Your ${fmt(data.amountInvested)} investment in ${data.planName} is active. Daily earning: ${fmt(data.dailyEarning)}. Matures: ${fmtDate(data.completesAt)}.`);
}

/* ─── Internship Activated ───────────────────────────────────────────────── */

export async function sendInternshipActivatedEmail(
  user: { email: string; name: string },
  data: { dailyEarning: number; totalEarning: number; completesAt: Date },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const rows = [
    row("Package", "<strong>2-Day Internship Package</strong>"),
    row("Cost", "FREE — No Deposit Required", true),
    row("Earning Per Day", fmt(data.dailyEarning)),
    row("Total You Will Earn", fmt(data.totalEarning), true),
    row("Day 1 Earning", fmt(data.dailyEarning)),
    row("Day 2 Earning", fmt(data.dailyEarning)),
    row("Completes On", fmtDate(data.completesAt)),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("🎓", "Internship Package Activated!")}
    ${para(`Congratulations! Your free 2-day Internship Package is now running. You will earn <strong>${fmt(data.totalEarning)}</strong> over the next 2 days — completely free, no deposit needed!`)}
    ${table(rows)}
    ${tip("<strong>Pro Tip:</strong> After your internship completes, use your earnings to invest in a premium plan for even bigger daily returns!")}
    ${cta("📊 View My Progress")}${hr()}${note("Earnings are credited automatically each day. No action required.")}`;
  return send(cfg, user.email, `🎓 Internship Activated — Earn ${fmt(data.totalEarning)} Free in 2 Days!`, layout(cfg.fromName, body),
    `Your free Internship Package is active! Earn ${fmt(data.totalEarning)} over 2 days. Completes: ${fmtDate(data.completesAt)}.`);
}

/* ─── Daily Earning Credited ─────────────────────────────────────────────── */

export async function sendDailyEarningEmail(
  user: { email: string; name: string },
  data: { earned: number; newBalance: number; isInternship?: boolean },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
  const label = data.isInternship ? "Internship Earning" : "Daily Return";
  const rows = [
    row(`${label} Credited`, fmt(data.earned), true),
    row("New Wallet Balance", fmt(data.newBalance), true),
    row("Credited At", time),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("💸", `+${fmt(data.earned)} Earned Today!`)}
    ${para(`Your ${label.toLowerCase()} has been credited to your wallet automatically.`)}
    ${table(rows)}
    ${para("Keep your investment active and watch your earnings grow day after day. 🚀")}
    ${cta("🏦 View My Wallet")}${hr()}${note("You receive this daily update while your investment is active.")}`;
  return send(cfg, user.email, `💸 ${label}: ${fmt(data.earned)} credited to your wallet`, layout(cfg.fromName, body),
    `${label}: ${fmt(data.earned)} credited. New balance: ${fmt(data.newBalance)}.`);
}

/* ─── Investment / Internship Completed ──────────────────────────────────── */

export async function sendInvestmentCompletedEmail(
  user: { email: string; name: string },
  data: { totalEarned: number; newBalance: number; isInternship?: boolean; planName?: string },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const label = data.isInternship ? "Internship Package" : `${data.planName ?? "Investment"} Plan`;
  const rows = [
    row("Plan Completed", `<strong>${label}</strong>`),
    row("Total Earned", fmt(data.totalEarned), true),
    row("Current Balance", fmt(data.newBalance), true),
    row("Status", '<span style="color:#16a34a;font-weight:700;">✅ Completed</span>'),
  ].join("");
  const reinvestTip = data.isInternship
    ? tip(`<strong>Great start!</strong> Your KES ${data.newBalance.toLocaleString("en-KE", { minimumFractionDigits: 2 })} balance is ready. Invest it in a premium plan and multiply your earnings every single day!`)
    : para("Your wallet is loaded and ready. Reinvest now to keep your money working for you!");
  const body = `
    ${hi(user.name)}
    ${hero("🏆", "Congratulations — Investment Matured!")}
    ${para(`Your <strong>${label}</strong> has fully matured! All earnings have been credited to your wallet.`)}
    ${table(rows)}
    ${reinvestTip}
    ${cta(data.isInternship ? "🚀 Start a Premium Plan" : "💼 Reinvest Now")}${hr()}${note("Your earnings are in your wallet, available for withdrawal or reinvestment.")}`;
  return send(cfg, user.email, `🏆 ${label} Completed — ${fmt(data.totalEarned)} Earned!`, layout(cfg.fromName, body),
    `Your ${label} has matured! Total earned: ${fmt(data.totalEarned)}. New balance: ${fmt(data.newBalance)}.`);
}

/* ─── Withdrawal Requested ───────────────────────────────────────────────── */

export async function sendWithdrawalRequestedEmail(
  user: { email: string; name: string },
  data: { amount: number; fee: number; netAmount: number; method: string; account: string; feePercent: number },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
  const methodLabel = data.method.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
  const rows = [
    row("Amount Requested", fmt(data.amount), true),
    row(`Processing Fee (${data.feePercent}%)`, fmt(data.fee)),
    row("You Will Receive", fmt(data.netAmount), true),
    row("Method", methodLabel),
    row("Account / Phone", data.account),
    row("Submitted At", time),
    row("Status", '<span style="color:#d97706;font-weight:700;">⏳ Under Review</span>'),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("📤", "Withdrawal Request Submitted", "#fffbeb", "#92400e")}
    ${para("Your withdrawal request has been received and is under review by our team. We'll notify you once it's processed.")}
    ${table(rows)}
    ${cta("📋 View Transaction History")}${hr()}${note("If you did not request this withdrawal, contact support immediately.")}`;
  return send(cfg, user.email, `📤 Withdrawal Request — ${fmt(data.amount)} under review`, layout(cfg.fromName, body),
    `Your withdrawal of ${fmt(data.amount)} via ${methodLabel} is under review. You will receive: ${fmt(data.netAmount)}.`);
}

/* ─── Withdrawal Approved ────────────────────────────────────────────────── */

export async function sendWithdrawalApprovedEmail(
  user: { email: string; name: string },
  data: { amount: number; method: string; account: string },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
  const methodLabel = data.method.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
  const rows = [
    row("Amount", fmt(data.amount), true),
    row("Method", methodLabel),
    row("Account / Phone", data.account),
    row("Approved At", time),
    row("Status", '<span style="color:#16a34a;font-weight:700;">✅ Approved & Processing</span>'),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("✅", "Withdrawal Approved!")}
    ${para(`Great news! Your withdrawal of <strong>${fmt(data.amount)}</strong> has been <strong>approved</strong> and is being processed. Funds will arrive in your account shortly.`)}
    ${table(rows)}
    ${tip("M-Pesa transfers typically arrive within minutes. Bank transfers may take 1–3 business days.")}
    ${cta("🏦 View My Wallet")}${hr()}${note("Thank you for using Zenti. We appreciate your trust.")}`;
  return send(cfg, user.email, `✅ Withdrawal Approved — ${fmt(data.amount)} being processed`, layout(cfg.fromName, body),
    `Your withdrawal of ${fmt(data.amount)} via ${methodLabel} has been approved and is being processed.`);
}

/* ─── Withdrawal Rejected ────────────────────────────────────────────────── */

export async function sendWithdrawalRejectedEmail(
  user: { email: string; name: string },
  data: { amount: number; reason?: string | null },
  smtpConfig?: SmtpConfig,
): Promise<EmailResult> {
  const cfg = smtpConfig ?? getDefaultSmtpConfig();
  const time = new Date().toLocaleString("en-KE", { timeZone: "Africa/Nairobi" });
  const rows = [
    row("Amount Refunded", fmt(data.amount), true),
    row("Rejected At", time),
    row("Status", '<span style="color:#dc2626;font-weight:700;">❌ Rejected & Refunded</span>'),
  ].join("");
  const body = `
    ${hi(user.name)}
    ${hero("❌", "Withdrawal Rejected", "#fef2f2", "#991b1b")}
    ${para(`Unfortunately, your withdrawal request was rejected. However, <strong>${fmt(data.amount)}</strong> has been <strong>refunded</strong> to your Zenti wallet immediately.`)}
    ${data.reason ? alert(`<strong>Reason:</strong> ${data.reason}`) : ""}
    ${table(rows)}
    ${para("Your refunded balance is available immediately. Contact our support team if you have questions.")}
    ${cta("📞 Contact Support")}${hr()}${note("Your funds are safe in your wallet and can be withdrawn again when ready.")}`;
  return send(cfg, user.email, `❌ Withdrawal Rejected — ${fmt(data.amount)} refunded to your wallet`, layout(cfg.fromName, body),
    `Your withdrawal of ${fmt(data.amount)} was rejected and refunded.${data.reason ? ` Reason: ${data.reason}` : ""}`);
}
