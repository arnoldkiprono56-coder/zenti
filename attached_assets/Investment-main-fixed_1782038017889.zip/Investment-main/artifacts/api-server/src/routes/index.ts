import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { requireVerified } from "../middlewares/auth";
import healthRouter from "./health";
import authRouter from "./auth";
import plansRouter from "./plans";
import investmentsRouter from "./investments";
import transactionsRouter from "./transactions";
import dashboardRouter from "./dashboard";
import adminRouter from "./admin";
import supportRouter from "./support";
import statsRouter from "./stats";
import referralsRouter from "./referrals";
import cronRouter from "./cron";
import otpRouter from "./otp";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/otp", otpRouter);
router.use("/plans", plansRouter);

// PayHero callback must be reachable without auth (called by PayHero servers).
// Mount the transactions router publicly ONLY for that one path; everything
// else falls through to the protected mount below.
router.use("/transactions", (req: Request, res: Response, next: NextFunction) => {
  if (req.method === "POST" && req.path === "/callback/payhero") {
    return (transactionsRouter as unknown as (req: Request, res: Response, next: NextFunction) => void)(req, res, next);
  }
  next();
});

// All routes below require a verified account
router.use("/investments", requireVerified, investmentsRouter);
router.use("/transactions", requireVerified, transactionsRouter);
router.use("/dashboard", requireVerified, dashboardRouter);
router.use("/admin", requireVerified, adminRouter);
router.use("/support", requireVerified, supportRouter);
router.use("/stats", requireVerified, statsRouter);
router.use("/referrals", requireVerified, referralsRouter);
router.use("/cron", cronRouter);

export default router;
