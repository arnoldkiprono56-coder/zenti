import { Router, Request, Response } from "express";
import { db } from "@workspace/db";
import {
  investmentsTable,
  usersTable,
  transactionsTable,
  activityLogsTable,
} from "@workspace/db";
import { eq, and, lte, or, isNull, sql } from "drizzle-orm";

const router = Router();

/**
 * POST /api/cron/process-returns
 *
 * Credits daily earnings for all active investments.
 * Called by Vercel Cron once per day (see vercel.json).
 * Protected by CRON_SECRET env var — Vercel passes it as
 *   Authorization: Bearer <CRON_SECRET>
 */
router.post("/process-returns", async (req: Request, res: Response) => {
  const cronSecret = process.env["CRON_SECRET"];

  // Require a secret in production to prevent unauthorized triggering
  if (cronSecret) {
    const authHeader = req.headers["authorization"] ?? "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (token !== cronSecret) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }
  }

  const now = new Date();
  const cutoff = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 24 h ago

  // Find active investments that haven't been credited in the last 24 hours
  const dueInvestments = await db
    .select()
    .from(investmentsTable)
    .where(
      and(
        eq(investmentsTable.status, "active"),
        or(
          isNull(investmentsTable.lastEarningAt),
          lte(investmentsTable.lastEarningAt, cutoff),
        ),
      ),
    );

  if (dueInvestments.length === 0) {
    res.json({ processed: 0, message: "No investments due for crediting" });
    return;
  }

  let processed = 0;
  let completed = 0;
  const errors: string[] = [];

  for (const inv of dueInvestments) {
    try {
      const dailyEarning = parseFloat(inv.dailyEarning ?? "0");
      const totalEarned = parseFloat(inv.totalEarned ?? "0");
      const expectedTotal = parseFloat(inv.expectedTotal ?? "0");

      const newTotalEarned = totalEarned + dailyEarning;
      const isComplete =
        (inv.completesAt != null && inv.completesAt <= now) ||
        newTotalEarned >= expectedTotal;

      // Credit earnings to the investment
      await db
        .update(investmentsTable)
        .set({
          totalEarned: String(Math.min(newTotalEarned, expectedTotal)),
          lastEarningAt: now,
          ...(isComplete ? { status: "completed" } : {}),
        })
        .where(eq(investmentsTable.id, inv.id));

      // Credit user's wallet balance and totalEarned
      await db
        .update(usersTable)
        .set({
          balance: sql`${usersTable.balance} + ${dailyEarning}`,
          totalEarned: sql`${usersTable.totalEarned} + ${dailyEarning}`,
          updatedAt: now,
        })
        .where(eq(usersTable.id, inv.userId));

      // Record a completed earning transaction
      await db.insert(transactionsTable).values({
        userId: inv.userId,
        type: "earning",
        amount: String(dailyEarning),
        status: "completed",
        notes: `Daily return credited for investment #${inv.id}`,
      });

      // Activity log
      await db.insert(activityLogsTable).values({
        userId: inv.userId,
        userEmail: "system",
        action: "earning_credited",
        details: `KES ${dailyEarning.toFixed(2)} daily return credited for investment #${inv.id}${isComplete ? " (investment completed)" : ""}`,
        ipAddress: "cron",
      });

      // Fire-and-forget WhatsApp earning / completion notification
      (async () => {
        try {
          const { sendMessage } = await import("../lib/whatsapp");
          const [usr] = await db
            .select({ phone: usersTable.phone, fullName: usersTable.fullName, balance: usersTable.balance, email: usersTable.email })
            .from(usersTable).where(eq(usersTable.id, inv.userId)).limit(1);
          if (!usr) return;
          const earningFmt = dailyEarning.toLocaleString("en-KE", { minimumFractionDigits: 2 });
          const newBal = (parseFloat(usr.balance ?? "0")).toLocaleString("en-KE", { minimumFractionDigits: 2 });
          if (isComplete) {
            const totalFmt = parseFloat(inv.expectedTotal ?? "0").toLocaleString("en-KE", { minimumFractionDigits: 2 });
            await sendMessage(usr.phone,
              `🏆 *Investment Completed — Zenti*\n\nCongratulations ${usr.fullName}!\n\nYour investment plan has matured and all earnings have been credited to your wallet.\n\n` +
              `💵 *Total Earned:* KES ${totalFmt}\n` +
              `🏦 *Wallet Balance:* KES ${newBal}\n\n` +
              `Ready to grow more? Log in and start a new plan today! 🚀`
            );
          } else {
            await sendMessage(usr.phone,
              `💸 *Daily Earning Credited — Zenti*\n\nHi ${usr.fullName},\n\nYour daily return has been credited to your wallet.\n\n` +
              `✅ *Earned Today:* KES ${earningFmt}\n` +
              `🏦 *Wallet Balance:* KES ${newBal}\n\n` +
              `Keep investing and watch your wealth grow! 📈`
            );
          }
        } catch { /* silent */ }
      })();

      // Fire-and-forget email earning / completion notification
      (async () => {
        try {
          const { sendDailyEarningEmail, sendInvestmentCompletedEmail } = await import("../lib/email");
          const [usr] = await db
            .select({ email: usersTable.email, fullName: usersTable.fullName, balance: usersTable.balance })
            .from(usersTable).where(eq(usersTable.id, inv.userId)).limit(1);
          if (!usr?.email) return;
          const newBalance = parseFloat(usr.balance ?? "0");
          if (isComplete) {
            await sendInvestmentCompletedEmail(
              { email: usr.email, name: usr.fullName },
              { totalEarned: parseFloat(inv.expectedTotal ?? "0"), newBalance, isInternship: inv.planId === 5 },
            );
          } else {
            await sendDailyEarningEmail(
              { email: usr.email, name: usr.fullName },
              { earned: dailyEarning, newBalance },
            );
          }
        } catch { /* silent */ }
      })();

      processed++;
      if (isComplete) completed++;
    } catch (err) {
      errors.push(`investment #${inv.id}: ${String(err)}`);
    }
  }

  res.json({
    processed,
    completed,
    errors: errors.length > 0 ? errors : undefined,
    timestamp: now.toISOString(),
  });
});

export default router;
