import { Router, Response } from "express";
import { db } from "@workspace/db";
import { usersTable, investmentsTable, transactionsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../middlewares/auth";

const router = Router();

router.get("/summary", requireAuth, async (req: AuthRequest, res: Response) => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);

  const activeInvestments = await db
    .select()
    .from(investmentsTable)
    .where(and(eq(investmentsTable.userId, req.userId!), eq(investmentsTable.status, "active")));

  const totalInvested = activeInvestments.reduce((sum, i) => sum + parseFloat(i.amountInvested ?? "0"), 0);

  const pendingWithdrawals = await db
    .select()
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'withdrawal' AND ${transactionsTable.status} = 'pending'`
    );
  const pendingWithdrawalsAmt = pendingWithdrawals.reduce((sum, t) => sum + parseFloat(t.amount), 0);

  // Today's earnings
  const todayEarnings = await db
    .select()
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.userId} = ${req.userId} AND ${transactionsTable.type} = 'earning' AND ${transactionsTable.createdAt}::date = CURRENT_DATE`
    );
  const todayEarningsAmt = todayEarnings.reduce((sum, t) => sum + parseFloat(t.amount), 0);

  // Internship progress
  let internshipProgress: number | null = null;
  if (user.internshipActivated) {
    const [internshipInv] = await db
      .select()
      .from(investmentsTable)
      .where(
        sql`${investmentsTable.userId} = ${req.userId} AND ${investmentsTable.status} = 'active'`
      )
      .limit(1);
    if (internshipInv) {
      const earned = parseFloat(internshipInv.totalEarned ?? "0");
      const expected = parseFloat(internshipInv.expectedTotal ?? "200");
      internshipProgress = Math.min(100, (earned / expected) * 100);
    }
  }

  res.json({
    balance: parseFloat(user.balance ?? "0"),
    totalInvested,
    totalEarned: parseFloat(user.totalEarned ?? "0"),
    activeInvestments: activeInvestments.length,
    pendingWithdrawals: pendingWithdrawalsAmt,
    todayEarnings: todayEarningsAmt,
    internshipProgress,
  });
});

export default router;
