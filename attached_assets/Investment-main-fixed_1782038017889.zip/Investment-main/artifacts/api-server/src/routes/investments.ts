import { Router, Response } from "express";
import { db } from "@workspace/db";
import { investmentsTable, plansTable, usersTable, transactionsTable, activityLogsTable, referralsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { requireAuth, AuthRequest } from "../middlewares/auth";
import { serializePlan } from "./plans";
import { updateReferrerTier } from "./referrals";

const router = Router();

router.get("/", requireAuth, async (req: AuthRequest, res: Response) => {
  const investments = await db
    .select()
    .from(investmentsTable)
    .where(eq(investmentsTable.userId, req.userId!))
    .orderBy(sql`${investmentsTable.startedAt} desc`);
  const planIds = [...new Set(investments.map(i => i.planId))];
  const plans = planIds.length > 0
    ? await db.select().from(plansTable).where(sql`${plansTable.id} = ANY(${sql.raw(`ARRAY[${planIds.join(",")}]`)})`)
    : [];
  const planMap = Object.fromEntries(plans.map(p => [p.id, p]));
  res.json(investments.map(i => serializeInvestment(i, planMap[i.planId])));
});

router.post("/internship", requireAuth, async (req: AuthRequest, res: Response) => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
  if (!user.isInternshipEligible) {
    res.status(400).json({ error: "Not eligible for the internship package" });
    return;
  }
  if (user.internshipActivated) {
    res.status(400).json({ error: "Internship package already activated" });
    return;
  }
  const [internshipPlan] = await db.select().from(plansTable).where(eq(plansTable.isInternship, true)).limit(1);
  if (!internshipPlan) {
    res.status(400).json({ error: "Internship plan not configured" });
    return;
  }
  const startedAt = new Date();
  const completesAt = new Date(startedAt.getTime() + 2 * 24 * 60 * 60 * 1000);
  const fixedEarning = parseFloat(internshipPlan.internshipFixedEarning ?? "200");
  const dailyEarning = fixedEarning / 2;
  const [investment] = await db.insert(investmentsTable).values({
    userId: req.userId!,
    planId: internshipPlan.id,
    amountInvested: "0",
    dailyEarning: String(dailyEarning),
    totalEarned: "0",
    expectedTotal: String(fixedEarning),
    startedAt,
    completesAt,
  }).returning();
  await db.update(usersTable).set({ internshipActivated: true }).where(eq(usersTable.id, req.userId!));
  await db.insert(activityLogsTable).values({
    userId: req.userId!,
    userEmail: user.email,
    action: "internship_activated",
    details: `User activated internship package`,
    ipAddress: req.ip || "unknown",
  });
  res.status(201).json(serializeInvestment(investment, internshipPlan));

  // Fire-and-forget internship activation notification
  (async () => {
    try {
      const { sendMessage } = await import("../lib/whatsapp");
      const matures = completesAt.toLocaleDateString("en-KE", { timeZone: "Africa/Nairobi", day: "numeric", month: "long", year: "numeric" });
      await sendMessage(user.phone,
        `🎓 *Internship Package Activated — Zenti*\n\nHi ${user.fullName},\n\nYour 2-day Internship Package is now active!\n\n` +
        `💵 *Fixed Earning:* KES ${fixedEarning.toLocaleString("en-KE", { minimumFractionDigits: 2 })}\n` +
        `🗓 *Completes:* ${matures}\n\n` +
        `Your earnings will be credited to your wallet automatically. Good luck! 🚀`
      );
    } catch { /* silent */ }
  })();

  // Fire-and-forget internship activation email
  (async () => {
    try {
      const { sendInternshipActivatedEmail } = await import("../lib/email");
      await sendInternshipActivatedEmail(
        { email: user.email, name: user.fullName },
        { dailyEarning, totalEarning: fixedEarning, completesAt },
      );
    } catch { /* silent */ }
  })();
});

router.post("/", requireAuth, async (req: AuthRequest, res: Response) => {
  const { planId, amount } = req.body;
  const [plan] = await db.select().from(plansTable).where(eq(plansTable.id, planId)).limit(1);
  if (!plan || !plan.isActive) {
    res.status(400).json({ error: "Plan not found or inactive" });
    return;
  }
  if (plan.isInternship) {
    res.status(400).json({ error: "Use the internship endpoint" });
    return;
  }
  const minDep = parseFloat(plan.minDeposit);
  const maxDep = parseFloat(plan.maxDeposit);
  if (amount < minDep || amount > maxDep) {
    res.status(400).json({ error: `Amount must be between KES ${minDep} and KES ${maxDep}` });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!)).limit(1);
  const balance = parseFloat(user.balance ?? "0");
  if (balance < amount) {
    res.status(400).json({ error: "Insufficient balance. Please deposit first." });
    return;
  }
  const dailyReturn = parseFloat(plan.dailyReturnPercent) / 100;
  const dailyEarning = amount * dailyReturn;
  const expectedTotal = dailyEarning * plan.durationDays;
  const startedAt = new Date();
  const completesAt = new Date(startedAt.getTime() + plan.durationDays * 24 * 60 * 60 * 1000);

  await db.update(usersTable)
    .set({ balance: String(balance - amount) })
    .where(eq(usersTable.id, req.userId!));

  const [investment] = await db.insert(investmentsTable).values({
    userId: req.userId!,
    planId: plan.id,
    amountInvested: String(amount),
    dailyEarning: String(dailyEarning),
    totalEarned: "0",
    expectedTotal: String(expectedTotal),
    startedAt,
    completesAt,
  }).returning();

  await db.insert(activityLogsTable).values({
    userId: req.userId!,
    userEmail: user.email,
    action: "investment_started",
    details: `Invested KES ${amount} in plan: ${plan.name}`,
    ipAddress: req.ip || "unknown",
  });

  // Fire-and-forget investment confirmation notification
  (async () => {
    try {
      const { sendMessage } = await import("../lib/whatsapp");
      const amtFmt = Number(amount).toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const dailyFmt = dailyEarning.toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const totalFmt = expectedTotal.toLocaleString("en-KE", { minimumFractionDigits: 2 });
      const matures = completesAt.toLocaleDateString("en-KE", { timeZone: "Africa/Nairobi", day: "numeric", month: "long", year: "numeric" });
      await sendMessage(user.phone,
        `📈 *Investment Started — Zenti*\n\nHi ${user.fullName},\n\nYour investment has been activated!\n\n` +
        `💰 *Plan:* ${plan.name}\n` +
        `💵 *Invested:* KES ${amtFmt}\n` +
        `📅 *Daily Earning:* KES ${dailyFmt}\n` +
        `🎯 *Expected Total:* KES ${totalFmt}\n` +
        `🗓 *Matures:* ${matures}\n\n` +
        `Sit back and watch your money grow! 💹`
      );
    } catch { /* silent */ }
  })();

  // Fire-and-forget investment started email
  (async () => {
    try {
      const { sendInvestmentStartedEmail } = await import("../lib/email");
      await sendInvestmentStartedEmail(
        { email: user.email, name: user.fullName },
        { planName: plan.name, amountInvested: amount, dailyEarning, expectedTotal, completesAt },
      );
    } catch { /* silent */ }
  })();

  // Mark referral as active and update referrer tier
  const referral = await db
    .select()
    .from(referralsTable)
    .where(eq(referralsTable.refereeId, req.userId!))
    .limit(1);
  if (referral.length > 0 && !referral[0].isActive) {
    await db.update(referralsTable)
      .set({ isActive: true })
      .where(eq(referralsTable.refereeId, req.userId!));
    await updateReferrerTier(referral[0].referrerId);
  }

  res.status(201).json(serializeInvestment(investment, plan));
});

router.get("/:id", requireAuth, async (req: AuthRequest, res: Response) => {
  const id = parseInt(String(req.params["id"]));
  const [inv] = await db.select().from(investmentsTable)
    .where(and(eq(investmentsTable.id, id), eq(investmentsTable.userId, req.userId!)))
    .limit(1);
  if (!inv) { res.status(404).json({ error: "Investment not found" }); return; }
  const [plan] = await db.select().from(plansTable).where(eq(plansTable.id, inv.planId)).limit(1);
  res.json(serializeInvestment(inv, plan));
});

export function serializeInvestment(inv: typeof investmentsTable.$inferSelect, plan?: typeof plansTable.$inferSelect) {
  const totalEarned = parseFloat(inv.totalEarned ?? "0");
  const expectedTotal = parseFloat(inv.expectedTotal ?? "0");
  const progressPercent = expectedTotal > 0 ? Math.min(100, (totalEarned / expectedTotal) * 100) : 0;
  return {
    id: inv.id,
    userId: inv.userId,
    planId: inv.planId,
    plan: plan ? serializePlan(plan) : undefined,
    amountInvested: parseFloat(inv.amountInvested ?? "0"),
    dailyEarning: parseFloat(inv.dailyEarning ?? "0"),
    totalEarned,
    expectedTotal,
    progressPercent,
    status: inv.status,
    startedAt: inv.startedAt,
    completesAt: inv.completesAt,
    lastEarningAt: inv.lastEarningAt,
  };
}

export default router;
