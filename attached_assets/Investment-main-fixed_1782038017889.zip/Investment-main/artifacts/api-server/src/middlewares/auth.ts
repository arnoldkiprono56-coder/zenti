import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.SESSION_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  // Hard-fail at boot: refuse to sign or verify tokens with a weak/missing secret.
  throw new Error("SESSION_SECRET environment variable is required and must be at least 32 characters.");
}
const SECRET: string = JWT_SECRET;

export interface AuthRequest extends Request {
  userId?: number;
  userRole?: string;
}

export function signToken(userId: number): string {
  return jwt.sign({ userId }, SECRET, { expiresIn: "30d" });
}

async function loadUserFromBearer(req: AuthRequest, res: Response): Promise<typeof usersTable.$inferSelect | null> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, SECRET) as { userId: number };
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, payload.userId)).limit(1);
    if (!user || user.status === "banned") {
      res.status(401).json({ error: "Account is suspended or banned" });
      return null;
    }
    req.userId = user.id;
    req.userRole = user.role;
    return user;
  } catch {
    res.status(401).json({ error: "Invalid token" });
    return null;
  }
}

export async function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const user = await loadUserFromBearer(req, res);
  if (!user) return;
  next();
}

export async function requireVerified(req: AuthRequest, res: Response, next: NextFunction) {
  const user = await loadUserFromBearer(req, res);
  if (!user) return;
  if (!user.isVerified) {
    res.status(403).json({
      error: "Account not verified. Please verify your phone number to continue.",
      code: "UNVERIFIED",
      phone: user.phone,
      email: user.email,
    });
    return;
  }
  next();
}

export async function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  await requireAuth(req, res, async () => {
    if (req.userRole !== "admin" && req.userRole !== "superadmin") {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    next();
  });
}
