/**
 * Bundles src/vercel.ts → dist/vercel.js (CJS) for Vercel serverless.
 * Run from the api-server package where esbuild is available.
 */

import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import { rm } from "node:fs/promises";

globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  const outdir = path.resolve(artifactDir, "dist-vercel");

  // Clean previous output to avoid "Two output files share the same path" errors
  await rm(outdir, { recursive: true, force: true });

  await esbuild({
    entryPoints: [path.resolve(artifactDir, "src/vercel.ts")],
    platform: "node",
    bundle: true,
    // ESM output so `export default app` compiles to native ESM.
    // Vercel's Node.js runtime loads .mjs files as ESM natively — no interop needed.
    format: "esm",
    outfile: path.resolve(outdir, "index.mjs"),
    logLevel: "info",
    // CJS packages (express, pg, bcryptjs…) need require() shim in ESM output
    banner: {
      js: `import { createRequire as __createRequire } from 'node:module';
import { fileURLToPath as __fileURLToPath } from 'node:url';
import { dirname as __dirname2 } from 'node:path';
const require = __createRequire(import.meta.url);
const __filename = __fileURLToPath(import.meta.url);
const __dirname = __dirname2(__filename);`,
    },
    // pino is not used in vercel.ts — no pino plugin needed
    external: [
      "*.node",
      "sharp",
      "canvas",
      "bcrypt",
      "argon2",
      "fsevents",
      "pg-native",
      "nodemailer",
      "thread-stream",
      "pino-worker",
      "pino-pretty",
      "pino-file",
    ],
  });
  console.log("✓ Vercel handler bundled → dist-vercel/index.mjs");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
