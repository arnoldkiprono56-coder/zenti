#!/usr/bin/env node
/**
 * Build + package the app for SmarterASP.NET deployment.
 *
 * Output: deploy/zenti-deploy.zip
 *
 * Structure inside the zip:
 *   web.config          ← IIS / iisnode routing
 *   server.js           ← CJS entry point for iisnode
 *   dist/               ← Bundled Express server (built by esbuild)
 *   dist/public/        ← Built React frontend (static files)
 *   package.json        ← Minimal manifest (no scripts needed at runtime)
 */

import { execSync } from "node:child_process";
import { cpSync, mkdirSync, rmSync, writeFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createWriteStream } from "node:fs";
import { resolve } from "node:path";

const root    = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const apiDir  = path.join(root, "artifacts", "api-server");
const feDir   = path.join(root, "artifacts", "invest-ke");
const deployDir = path.join(root, "deploy");
const zipPath   = path.join(root, "deploy", "zenti-deploy.zip");

function run(cmd, cwd = root) {
  console.log(`\n▶ ${cmd}`);
  execSync(cmd, { cwd, stdio: "inherit" });
}

// ── 1. Clean ─────────────────────────────────────────────────────────────────
console.log("\n📦 Cleaning previous deploy...");
rmSync(deployDir, { recursive: true, force: true });
mkdirSync(deployDir, { recursive: true });

// ── 2. Build backend ─────────────────────────────────────────────────────────
console.log("\n🔨 Building Express API server...");
run("pnpm --filter @workspace/api-server run build", root);

// ── 3. Build frontend ────────────────────────────────────────────────────────
console.log("\n🔨 Building React frontend...");
run("pnpm --filter @workspace/invest-ke run build", root);

// ── 4. Copy backend dist ──────────────────────────────────────────────────────
console.log("\n📂 Copying API server dist...");
cpSync(path.join(apiDir, "dist"), path.join(deployDir, "dist"), { recursive: true });

// ── 5. Copy frontend build into dist/public ───────────────────────────────────
const feDistDir = path.join(feDir, "dist", "public");
const feFallback = path.join(feDir, "dist"); // in case publicDir is root
const feSource = existsSync(feDistDir) ? feDistDir : feFallback;
console.log(`\n📂 Copying React frontend from ${feSource}...`);
mkdirSync(path.join(deployDir, "dist", "public"), { recursive: true });
cpSync(feSource, path.join(deployDir, "dist", "public"), { recursive: true });

// ── 6. Copy iisnode entry files ───────────────────────────────────────────────
console.log("\n📂 Copying web.config and server.js...");
cpSync(path.join(apiDir, "web.config"), path.join(deployDir, "web.config"));
cpSync(path.join(apiDir, "server.js"),  path.join(deployDir, "server.js"));

// ── 7. Write a minimal package.json ──────────────────────────────────────────
writeFileSync(
  path.join(deployDir, "package.json"),
  JSON.stringify({ name: "zenti", version: "1.0.0", type: "module" }, null, 2)
);

// ── 8. Zip ────────────────────────────────────────────────────────────────────
console.log("\n🗜  Creating zip...");
run(`cd "${deployDir}" && zip -r "${zipPath}" .`, root);

console.log(`
✅  Done!
   Deploy zip: ${zipPath}

📋  Next steps for SmarterASP.NET:
   1. Upload zenti-deploy.zip to your hosting account
   2. Extract it into your website root (public_html or wwwroot)
   3. In web.config, update DATABASE_URL and SESSION_SECRET with your real values
   4. In SmarterASP.NET control panel → Application Settings, set Node.js version to 18 or higher
   5. Visit your site — if you see errors, check iisnode-logs/ folder
`);
