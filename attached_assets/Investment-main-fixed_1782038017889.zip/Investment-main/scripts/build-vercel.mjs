/**
 * Vercel Build Output API v3 orchestration script.
 * Calls pnpm to build frontend + API, then assembles .vercel/output/.
 *
 * No direct esbuild import here — esbuild lives in the api-server package.
 */

import path from "node:path";
import { fileURLToPath } from "node:url";
import { execSync } from "node:child_process";
import { rm, mkdir, writeFile, cp } from "node:fs/promises";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

const outputDir = path.resolve(root, ".vercel/output");
const staticDir = path.resolve(outputDir, "static");
const funcDir = path.resolve(outputDir, "functions/api.func");

function run(cmd, opts = {}) {
  console.log(`\n$ ${cmd}`);
  execSync(cmd, { cwd: root, stdio: "inherit", ...opts });
}

async function main() {
  console.log("\n=== InvestKE · Vercel Build Output API v3 ===\n");

  // ── 1. Clean output directory ──────────────────────────────────────────────
  await rm(outputDir, { recursive: true, force: true });
  await mkdir(staticDir, { recursive: true });
  await mkdir(funcDir, { recursive: true });

  // ── 2. Build frontend (Vite) ───────────────────────────────────────────────
  console.log("\n▶ Building frontend…");
  run("pnpm --filter @workspace/invest-ke run build", {
    env: {
      ...process.env,
      NODE_ENV: "production",
      BASE_PATH: "/",
      PORT: "3000",
    },
  });

  // ── 3. Bundle API for Vercel (esbuild via api-server package) ─────────────
  console.log("\n▶ Bundling API…");
  run("node build-vercel.mjs", {
    cwd: path.resolve(root, "artifacts/api-server"),
  });

  // ── 4. Copy frontend static files ─────────────────────────────────────────
  await cp(
    path.resolve(root, "artifacts/invest-ke/dist/public"),
    staticDir,
    { recursive: true },
  );
  console.log("✓ Frontend copied → .vercel/output/static/");

  // ── 5. Copy bundled API function file ─────────────────────────────────────
  await cp(
    path.resolve(root, "artifacts/api-server/dist-vercel/index.mjs"),
    path.resolve(funcDir, "index.mjs"),
  );
  console.log(`✓ API function copied → .vercel/output/functions/api.func/`);

  // ── 6. Write Vercel function config ───────────────────────────────────────
  await writeFile(
    path.resolve(funcDir, ".vc-config.json"),
    JSON.stringify(
      {
        runtime: "nodejs20.x",
        handler: "index.mjs",
        launcherType: "Nodejs",
        shouldAddHelpers: true,
        shouldAddSourcemapSupport: false,
      },
      null,
      2,
    ),
  );
  console.log("✓ .vc-config.json written");

  // ── 7. Write Vercel routing config ────────────────────────────────────────
  await writeFile(
    path.resolve(outputDir, "config.json"),
    JSON.stringify(
      {
        version: 3,
        routes: [
          // Send all /api/* requests to the Express serverless function
          { src: "^/api(/.*)?$", dest: "/api" },
          // Serve static assets by filename match first
          { handle: "filesystem" },
          // SPA fallback — everything else serves index.html
          { src: "/(.*)", dest: "/index.html" },
        ],
      },
      null,
      2,
    ),
  );
  console.log("✓ config.json written");

  console.log("\n=== Build complete ✓ ===");
  console.log("Output: .vercel/output/\n");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
