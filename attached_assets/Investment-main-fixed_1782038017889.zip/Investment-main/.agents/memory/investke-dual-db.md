---
name: InvestKE dual DB setup
description: Replit internal DB for dev, Neon for production — both must be kept in sync manually
---

## Rule
Any time schema changes are made (drizzle push) or seed data is added, do it to BOTH databases:
1. Replit internal DB: `pnpm --filter @workspace/db run push` (uses DATABASE_URL auto-set by Replit)
2. Neon production DB: `DATABASE_URL="<neon_url>" pnpm --filter @workspace/db run push`
Then seed with psql using both connection strings.

**Why:** The platform uses Neon as the production database on Vercel. Replit's internal PostgreSQL is only the dev database. If Neon is missing schema, production breaks — and vice versa.

**How to apply:** After any `drizzle-kit push`, immediately run the same push against Neon URL. After seeding Replit DB, run the same psql INSERT commands against Neon. Watch for duplicate rows if ON CONFLICT clause is missing (add unique constraints to plans.name if needed).

## Key facts
- Neon URL stored in user's Vercel project env vars as DATABASE_URL
- Replit DATABASE_URL is runtime-managed (cannot be overridden in Replit secrets)  
- Plans table has no unique constraint on name — use `DELETE FROM plans WHERE id NOT IN (SELECT MIN(id) FROM plans GROUP BY name)` to deduplicate
- Admin users: admin@investke.co.ke / Admin@1234! (superadmin), test@investke.co.ke / Test@1234!
- Bcrypt hash generation: `node -e "const b=require('bcryptjs'); b.hash('pass',10).then(console.log)"` from `artifacts/api-server/` dir
- platform_settings may have duplicate rows after schema push — deduplicate before seeding
