---
name: InvestKE auth pattern
description: JWT auth setup, token storage, and TanStack Query quirks for the invest-ke frontend
---

# JWT Auth Pattern

**Rule:** `setAuthTokenGetter(() => localStorage.getItem("investke_token"))` is called once at the top of `use-auth.ts` (outside any hook/component). This injects the token into every API call via the custom fetch wrapper.

**Why:** Orval-generated hooks use a `customFetch` wrapper that calls the getter function before each request. Calling it at module load time (not inside a component) ensures it's set before any query fires.

**How to apply:** If you add a new auth storage mechanism (e.g. cookies), update the getter in `use-auth.ts` only — all hooks pick it up automatically.

# TanStack Query v5 quirk

`UseQueryOptions<TData, TError, TData, QueryKey>` requires `queryKey` as a required property in v5. When passing `{ enabled, retry }` options to a generated `useGetMe()` hook, TypeScript complains about the missing `queryKey`.

**Fix:** Cast the options object `as any`:
```ts
useGetMe({ query: { enabled: !!token, retry: false } } as any)
```

**Why:** The hook internally provides the queryKey, so it's safe to omit it at the call site — but the type system doesn't know that.
