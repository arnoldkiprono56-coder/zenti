---
name: InvestKE DB seeding
description: How to seed the InvestKE database; bcrypt hash generation and admin credentials
---

# Seeding approach

**Rule:** Seed via `psql "$DATABASE_URL"` directly with SQL INSERT statements. Do NOT try to run tsx/node scripts from /tmp — they can't resolve workspace packages (drizzle-orm, pg).

**Why:** The monorepo packages are only resolvable within their own workspace directories. Scripts in /tmp or outside the workspace cannot `require('pg')` or import drizzle.

**Alternative:** Run node scripts from `artifacts/api-server/` directory where `node_modules/` contains `pg` and `bcryptjs`.

# Admin credentials (seeded)

- Email: admin@investke.co.ke
- Password: Admin@1234!
- Role: superadmin

# Bcrypt hash generation

```bash
cd artifacts/api-server && node -e "const b=require('bcryptjs'); b.hash('Admin@1234!',10).then(console.log);"
```

Then update in DB:
```sql
UPDATE users SET password_hash='<hash>' WHERE email='admin@investke.co.ke';
```
