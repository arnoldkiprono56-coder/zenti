---
name: InvestKE API server restart requirement
description: The API server dev script is build+start, not watch — must restart workflow after code changes
---

**Rule:** Any change to `artifacts/api-server/src/**` requires restarting the "artifacts/api-server: API Server" workflow to take effect.

**Why:** The dev script is `NODE_ENV=development pnpm run build && pnpm run start`. It builds once at startup and runs the compiled dist. There is no file-watching or hot reload.

**How to apply:** After editing backend code, call `restart_workflow("artifacts/api-server: API Server")`. Then verify with `curl localhost:80/api/healthz`.

**Proxy rule:** Always test via `localhost:80/api/...` (the shared proxy), never `localhost:8080/...` directly. The proxy routes `/api` to port 8080.
