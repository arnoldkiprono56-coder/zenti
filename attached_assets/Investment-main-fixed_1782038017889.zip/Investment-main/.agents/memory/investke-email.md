---
name: InvestKE email notifications
description: Comprehensive email notification system — all typed helpers in email.ts, fire-and-forget in all routes
---

## Rule
All email notifications are fire-and-forget IIFEs in routes. Never await them in the main request flow. Use `getDefaultSmtpConfig()` (reads SMTP_USER/SMTP_PASS from env) — no DB query needed for basic config.

**Why:** Email failures must never block user-facing responses. SMTP credentials are in Replit secrets (SMTP_USER, SMTP_PASS) and Vercel env vars.

**How to apply:** Pattern in each route:
```ts
(async () => {
  try {
    const { sendXxxEmail } = await import("../lib/email");
    await sendXxxEmail({ email: user.email, name: user.fullName }, data);
  } catch { /* silent */ }
})();
```

## Exported functions in email.ts
- `getDefaultSmtpConfig(settings?)` — builds SmtpConfig from env vars + optional DB settings
- `sendEmailOtp(payload, smtpConfig?)` — OTP verification code
- `sendEmailNotification(payload, smtpConfig?)` — generic, used by admin approve/reject
- `sendWelcomeEmail(user, smtpConfig?)` — on register
- `sendDepositConfirmedEmail(user, data, smtpConfig?)` — on PayHero callback success
- `sendInvestmentStartedEmail(user, data, smtpConfig?)` — on investment create
- `sendInternshipActivatedEmail(user, data, smtpConfig?)` — on internship activate
- `sendDailyEarningEmail(user, data, smtpConfig?)` — in cron job
- `sendInvestmentCompletedEmail(user, data, smtpConfig?)` — in cron job when matured
- `sendWithdrawalRequestedEmail(user, data, smtpConfig?)` — on withdrawal create
- `sendWithdrawalApprovedEmail(user, data, smtpConfig?)` — in admin approve route
- `sendWithdrawalRejectedEmail(user, data, smtpConfig?)` — in admin reject route

## SMTP config
- Gmail: smtp.gmail.com:587, uses App Password (not account password)
- Secrets: SMTP_USER=shadowvybez001@gmail.com, SMTP_PASS=Gmail App Password
- Set smtp_from_email in platform_settings table to same Gmail address
- verification_method should be 'email' in platform_settings
