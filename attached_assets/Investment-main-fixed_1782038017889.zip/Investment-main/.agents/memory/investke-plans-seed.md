---
name: InvestKE plans must be seeded
description: Plans table has no auto-seed; internship "not configured" = empty plans table
---

## Rule
The plans table is NOT auto-seeded by migrations. It must be manually seeded via psql in both Replit DB and Neon.

**Why:** "Internship plan not configured" error comes from `plansTable.isInternship = true` returning no rows — i.e., the table is empty.

**How to apply:** After any fresh DB setup or schema push, run:
```sql
INSERT INTO plans (name, description, min_deposit, daily_return_percent, duration_days, is_active, is_internship, internship_fixed_earning) VALUES
('Starter', 'Perfect for beginners.', '500.00', '3.00', 7, true, false, NULL),
('Silver', 'Mid-tier plan.', '5000.00', '5.00', 14, true, false, NULL),
('Gold', 'Premium 7.5% daily returns.', '25000.00', '7.50', 21, true, false, NULL),
('Platinum', 'Elite 10% daily returns.', '100000.00', '10.00', 30, true, false, NULL),
('Internship Package', 'Free 2-day package, KES 200 guaranteed.', '0.00', '0.00', 2, true, true, '200.00')
ON CONFLICT DO NOTHING;
```

## Other seeding notes
- Internship plan must have `is_internship=true` and `internship_fixed_earning='200.00'`
- cron.ts checks `inv.planId === 5` to detect internship for completion email — if plan IDs change, update this
- platform_settings needs exactly 1 row; deduplicate with `DELETE FROM platform_settings WHERE id NOT IN (SELECT MIN(id) FROM platform_settings)`
